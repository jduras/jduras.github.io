
# set working directory
# setwd("C:/Drive/Dropbox/User/Academic/06TexasTech/02Teaching/02 5316 Time Series Econometrics Spring 2016/Codes")
# setwd("C:/User/Courses/E5316/Codes")

# import the data on the growth rate of GDP, convert it into time series ts object
#  this data can be downloaded from here
#  http://faculty.chicagobooth.edu/ruey.tsay/teaching/fts3/q-gnp4791.txt
y <- ts(scan(file="q-gnp4791.txt"), start=c(1947,2), frequency=4)


# change the plot window layout to 1 row with 3 columns
par(mfrow=c(1,3))
# plot y
plot(y, xlab="", ylab="")
# plot ACF for y up to lag 24
acf(as.data.frame(y),type='correlation',lag=24)
# plot PACF for y up to lag 24
acf(as.data.frame(y),type='partial',lag=24, main="")


# estimate an AR(1) model - there is only one significant coefficient in the PACF plot for y
m1 <- arima(y, order=c(1,0,0))
# show the structure of object m1
str(m1)
# print out results for m1
m1
# diagnostics for the AR(1) model - note that there seems to be a problem with remaining serial correlation at lag 2
tsdiag(m1,gof.lag=24)


# estimate an AR(2) model to deal with the problem of remaining serial correlation at lag 2
m2 <- arima(y, order=c(2,0,0))
m2
# diagnostics for the AR(2) model - note that the problem with remaining serial correlation at lag 2 is gone
tsdiag(m2,gof.lag=24)


# estimate an AR(3) model since PACF for lag 2 and 3 are comparable in size
m3 <- arima(y, order=c(3,0,0))
m3
# diagnostics for the AR(3) model
tsdiag(m3,gof.lag=24)

# z-statistics for coefficients of AR(3) model - phi2 is signifficant at 5% level, phi3 is marginally insignifficant
m3$coef/sqrt(diag(m3$var.coef))
# p values
(1-pnorm(abs(m3$coef)/sqrt(diag(m3$var.coef))))*2

# use AIC to choose order p of the AR model
m <- ar(y,method="mle")
str(m)
m
m$order
# note that AIC prefers AR(3) to AR(2)
m$aic

# note that BIC prefers AR(2) to AR(3), in general BIC puts a larger penalty on additional coefficients than AIC
BIC(m2)
BIC(m3)

# Ljung-Box test - for residuals of a model adjust the degrees of freedom m by subtracting the number of parameters g
# this adjustment will not make a big difference if m is large but matters if m is small

m2.LB.lag12 <- Box.test(m2$residuals, lag=12, type="Ljung")
str(m2.LB.lag12)
m2.LB.lag12
1-pchisq(m2.LB.lag12$statistic,10)

m2.LB.lag16 <- Box.test(m2$residuals, lag=16, type="Ljung")
m2.LB.lag16
1-pchisq(m2.LB.lag16$statistic,14)

