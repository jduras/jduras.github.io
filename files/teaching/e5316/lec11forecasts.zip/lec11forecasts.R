
# obtain data on GDP, calculate growth rate
library(Quandl)
rGDP <- Quandl("FRED/GDPC1", type="zoo")
dlrGDP <- diff(log(rGDP))

# split sample - estimation and prediction subsamples
fstQ <- 1947.25  # 1947Q2
lstQ <- 2008.75  # 2008Q4
dlrGDPp1 <- window(dlrGDP, end=lstQ)
dlrGDPp2 <- window(dlrGDP, start=lstQ+0.25)

# largest forecast step lmax = T-h, given how the sample was split
lmax <- length(dlrGDPp2)


# plot ACF and PACF - AR(1) or MA(2) seem appropriate
par(mfrow=c(1,2))
acf(coredata(dlrGDPp1), type="correlation")
acf(coredata(dlrGDPp1), type="partial")


library(forecast)

# m1 <- arima(dlrGDPp1, order=c(1,0,0))
m1 <- auto.arima(dlrGDPp1)
m1
tsdiag(m1)

# evaluate in-sample accuracy based on model residuals
accuracy(m1)



# create 1 to lmax step ahead forecasts - forecast origin which is fixed at 2008Q4
m1.f.1tol <- forecast(m1, lmax)
# evaluate accuracy of both in sample residuals (training set) and out-of-sample 1 to l step ahead forecasts (test set)
# note that in-sample measures are exactly same as those obtained above on line 31 using accuracy(m1)
accuracy(m1.f.1tol, dlrGDPp2)
# evaluate only accuracy of out-of-sample 1 to l step ahead forecasts for 2009Q1-2015Q4 (test set)
accuracy(m1.f.1tol$mean, dlrGDPp2)



# create 1-step ahead forecasts - forecast origin is moving from 1947Q2 to 2015Q3 but always use same estimated model m1
m1.f <- Arima(x=dlrGDP, model=m1)
# evaluate accuracy of model throughout the whole sample 1947Q2 to 2015Q4
accuracy(m1.f)
# which is the same as running
m1.f.1.all <- m1.f$x - m1.f$residuals
accuracy(m1.f.1.all, dlrGDP)
# recover only the out of sample 1 step ahead forecasts
m1.f.1 <- window(m1.f$x-m1.f$residuals, start=lstQ+0.25)
# evaluate accuracy of out-of-sample 1-step ahead forecasts
accuracy(m1.f.1, dlrGDPp2)



# create l step ahead forecasts under either fixed, recursive or rolling scheme
l <- 1
n <- lmax-l+1               # this is T-h-l+1
m1.f.l <- zoo()
for(i in 1:n)
{
    # fixed scheme - model is not reestimated, but new observation is included in each period - this gives same results as line 55 above
    y <- window( dlrGDP, end=lstQ+(i-1)/4 )
    m1new <- Arima(y, model=m1)
    # extract and save 1 step ahead forecast
    m1.f.l <- c(m1.f.l, forecast(m1new, l)$mean)
}
m1.f.l <- as.ts(m1.f.l)
# evaluate accuracy of out of sample forecasts based on the above forecasting scheme
accuracy(m1.f.l, dlrGDPp2)


# note: to implement a recursive or a rolling scheme replace lines 66 and 67 by one of the below:

# recursive scheme - reestimate the AR(1) model after new observation is available (use all available observations in estimation)
#  y <- window( dlrGDP, end=lstQ+(i-1)/4 )
#  m1new <- arima(y, order=c(1,0,0))

# rolling  scheme - reestimate the AR(1) model always using same number of observations but rolling sample to include new data
#  y <- window( dlrGDP, start=fstQ+(i-1)/4, end=lstQ+(i-1)/4 )
#  m1new <- arima(y, order=c(1,0,0))


# summary
accuracy(m1.f.1tol, dlrGDPp2)
accuracy(m1.f.1, dlrGDPp2)
accuracy(m1.f.l, dlrGDPp2)


# note that for AR(p) model l-step ahead forecast converges to unconditional mean as l -> infinity
par(mfrow=c(1,1))
plot(m1.f.1tol, type="o", pch=16, xlim=c(2005,2016), ylim=c(-0.03,0.03), main=strsplit(m1.f.1tol$method,' ')[[1]][1])
lines(m1.f.1tol$mean, type="p", pch=16, lty="dotted", col="blue")
lines(m1.f.1, type="o", pch=17, lty="dotted", col="green")
lines(m1.f.l, type="o", pch=18, lty="dotted", col="red")
lines(dlrGDP, type="o", pch=16, lty="dotted")

