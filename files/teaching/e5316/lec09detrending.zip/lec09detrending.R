
# data on GDP
library(Quandl)
Quandl.api_key('DLk9RQrfTVkD4UTKc7op')
rGDP <- Quandl("FRED/GDPC1", type="zoo")
lrGDP <- log(rGDP)

# deterministic linear trend can be construct using the index function - note that an increase in t by 1 represents one extra year
head(index(lrGDP))
head(as.numeric(index(lrGDP)))

# fit linear trend line - coefficient for trend 0.032 means that the average annual growth rate of GDP in the sample is about 3.2%
m <- lm(coredata(lrGDP) ~ index(lrGDP))
m

par(mfrow=c(1,2))

# plot data and linear trend
plot(index(lrGDP), coredata(lrGDP), type="l")
abline( lm(coredata(lrGDP) ~ index(lrGDP)) )

# plot residuals - deviations around the linear trend
plot(index(lrGDP), m$residuals, type="l")

# plot ACF and PACF
acf(m$residuals, type="correlation")
acf(m$residuals, type="partial")

# model residuals as an AR(3) process
#  phi(B)*res_t = a_t
armaRES <- arima(m$residuals, order=c(3,0,0))
armaRES
tsdiag(armaRES)

# fit linear trend + model residuals as AR(3) process, all in one command
#  log(GDP_t) = c + mu*t + res_t and then phi(B)*res_t = a_t
# so that
#  phi(B) * (log(GDP_t) - mu*t ) = c + a_t
armaGDP <- arima(lrGDP, order=c(3,0,0), xreg=index(lrGDP))
armaGDP
tsdiag(armaGDP)

# note: xreg can be also used to include dummies for days in week Christmas, Thanskgiving, Easter, ...
