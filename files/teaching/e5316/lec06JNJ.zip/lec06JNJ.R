
# set working directory
setwd("C:/Drive/Dropbox/User/Academic/06TexasTech/02Teaching/02 5316 Time Series Econometrics Spring 2016/Codes")
# setwd("C:/User/Courses/E5316/Codes")

# import the data on earnings per share for Johnson and Johnson
#  this data can be downloaded from
#  http://faculty.chicagobooth.edu/ruey.tsay/teaching/fts3/q-jnj.txt
y <- ts(scan(file="../Sources/Books/tsay/data/q-jnj.txt"), start=c(1960,1), frequency=4)
str(y)

# split sample - into two parts
yall <- y
y1 <- window(yall, end=c(1978,4))
y2 <- window(yall, start=c(1979,1))

# we'll use first part of the sample to identify and estimate the model
y <- y1
str(y)

# construct log, log-change ans seasonal log change of earnings per share for Johnson and Johnson
ly <- log(y)
dly1 <- diff(ly)
dly4 <- diff(ly,4)
dly4_1 <- diff(diff(ly,4))


# plot data
par(mfrow=c(2,3))
plot(y, xlab="", ylab="", main=expression(y))
plot(ly, xlab="", ylab="", main=expression(log(y)))
plot.new()
plot(dly1, xlab="", ylab="", main=expression(paste(Delta, "log(y)")))
plot(dly4, xlab="", ylab="", main=expression(paste(Delta[4], "log(y)")))
plot(dly4_1, xlab="", ylab="", main=expression(paste(Delta, Delta[4], "log(y)")))


# plot ACF and PACF
library(zoo)
maxlag <-24
par(mfrow=c(2,4))
plot(acf(coredata(ly), type='correlation', lag=maxlag, plot=FALSE), ylab="", main=expression(paste("ACF for log(y)")))
plot(acf(coredata(dly1), type='correlation', lag=maxlag, plot=FALSE), ylab="", main=expression(paste("ACF for ", Delta,"log(y)")))
plot(acf(coredata(dly4), type='correlation', lag=maxlag, plot=FALSE), ylab="", main=expression(paste("ACF for ", Delta[4], "log(y)")))
plot(acf(coredata(dly4_1), type='correlation', lag=maxlag, plot=FALSE), ylab="", main=expression(paste("ACF for ", Delta, Delta[4], "log(y)")))
acf(coredata(ly), type='partial', lag=maxlag, ylab="", main=expression(paste("PACF for log(y)")))
acf(coredata(dly1), type='partial', lag=maxlag, ylab="", main=expression(paste("PACF for ", Delta, "log(y)")))
acf(coredata(dly4), type='partial', lag=maxlag, ylab="", main=expression(paste("PACF for ", Delta[4], "log(y)")))
acf(coredata(dly4_1), type='partial', lag=maxlag, ylab="", main=expression(paste("PACF for ", Delta,Delta[4], "log(y)")))



library(forecast)

# estimate model - seasonally differenced data
m1 <- arima(dly4_1,order=c(0,0,1),seasonal=list(order=c(0,0,1),period=4))
m1
tsdiag(m1,gof.lag=36)
BIC(m1)
AIC(m1)

# estimate model - data not differenced
m2 <- Arima(dly1, order=c(0,0,1), seasonal=list(order=c(0,1,1),period=4), include.drift=TRUE)
m2
tsdiag(m2,gof.lag=36)
BIC(m2)
AIC(m2)

# estimate model - data not differenced
m3 <- Arima(ly, order=c(0,1,1), seasonal=list(order=c(0,1,1),period=4))
m3
tsdiag(m3,gof.lag=36)
BIC(m3)
AIC(m3)


# construct and plot forecasts
par(mfrow=c(1,2), cex=0.75)

m2.fcast <- forecast(m2, h=8)
plot(m2.fcast, xlim=c(1970,1981))
lines(diff(log(yall)))

m3.fcast <- forecast(m3, h=8)
plot(m3.fcast, xlim=c(1970,1981), ylim=c(0.5,3.5))
lines(log(yall))


# search for best model using BIC criteria
?auto.arima

m4a <- auto.arima(dly4_1, ic="bic")
m4a

m4b <- auto.arima(dly4_1, ic="bic", seasonal=TRUE, stationary=TRUE, stepwise=FALSE)
m4b

m4d <- auto.arima(ly, ic="bic", seasonal=TRUE, stationary=FALSE, stepwise=FALSE)
m4d

