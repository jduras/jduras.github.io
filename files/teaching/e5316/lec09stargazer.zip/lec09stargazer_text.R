
library(Quandl)
rGDP <- Quandl("FRED/GDPC1", type="zoo")
dlrGDP <- diff(log(rGDP))

ma2 <- arima(dlrGDP, order=c(0,0,2))
ar1 <- arima(dlrGDP, order=c(1,0,0))
ar3 <- arima(dlrGDP, order=c(3,0,0))

library(stargazer)
stargazer(ma2, ar1, ar3, type="text")

