
# example of SVAR with sign restrictions - Uhlig (2005)

rm(list = ls())

set.seed(12345)

# install.packages("VARsignR")
library(VARsignR)
# monthly data for US, from 1965:1 to 2003:12
#  y Real GDP, yd GDP deflator, p commodity price index,
#  i FED funds rate, rnb non-borrowed reserves, rt total reserves
# all variables except the FED funds rate are the log of the original data series times 100
data(uhligdata)
str(uhligdata)
head(uhligdata)
help(uhligdata)
plot(uhligdata)

# define varaible labels for plots below
vl <- c("GDP","GDP Deflator","Comm.Pr.Index","Fed Funds Rate", "NB Reserves", "Total Reserves")

# sign restrictions imposed
# a contractionary monetary policy shock
# - does not decrease the FED's policy rate for x months after the shock
# - does not increase commodity prices for x months after the shock
# - does not increase inflation for x months after the shock
# - does not increase non-borrowed reserves for x months after the shock

# ordering of variables in the data set
#  y, yd, p, i, rnb, rt
# thus sign restrictions are on the 2nd, 3rd, 4th, and 5th variable
# and the first element of constr indicates the shock of interest
constr <- c(+4,-3,-2,-5)

# estimate a VAR with 12 lags, no constant, generate IRF with 60 steps ahead
# KMIN and KMAX denote the first and the last period of the responses to which the sign restrictions apply
# KMIN=1, KMAX=6 implies that the restrictions apply from the point of impact up to the 6th period of the response
# draws=200, subdraws=200 means that 200 draws from the posterior and 200 subdraws for each posterior draw
# are used to generate the impulse vectors and the candidate impulse responses to which the rejection algorithm will be applied
# nkeep denotes the desired number of accepted draws

# estimate model using Uhlig's (2005) Rejection Method
model1 <- uhlig.reject(Y=uhligdata, nlags=12, constant=FALSE, steps=60, constrained=constr, KMIN=1, KMAX=6, draws=200, subdraws=200, nkeep=1000)
# estimate model using Rubio-Ramirez et al's (2010) Rejection Method
# model2 <- rwz.reject(Y=uhligdata, nlags=12, constant=FALSE, steps=60, constrained=constr, KMIN=1, KMAX=6, draws=200, subdraws=200, nkeep=1000)

# plot IRFs
irfplot(model1$IRFS, type="median", labels=vl, bands=c(0.025,0.975))

# plot FEVD
fevdplot(model1$FEVDS, label=vl)
fevdplot(model1$FEVDS, label=vl, bands=NULL)

# print out a table with forecast error variance decomposition
fevd.table <- fevdplot(model1$FEVDS, table=TRUE, label=vl, periods=c(1,10,20,30,40,50,60))
print(fevd.table)
