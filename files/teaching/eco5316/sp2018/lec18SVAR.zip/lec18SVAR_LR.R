
# example of SVAR with long run restriction - Blanchard and Quah (1989)

# remove everything from the environment
rm(list = ls())

library(magrittr)
library(dplyr)
library(tidyquant)
library(timetk)
library(ggplot2)
library(vars)

theme_set(theme_bw())


#### Data ####

quandl_api_key('DLk9RQrfTVkD4UTKc7op')

# obtain data on real GDP and unemployment rate
# construct approximate quarter-over-quarter GDP growth rates
y.tbl <- inner_join(tq_get("GDPC1", get  = "economic.data", from = "1947-01-01", to = "2017-12-31") %>%
                        rename(rGDP = price) %>%
                        mutate(dlrGDP = 100*Delt(rGDP, type = "log")),
                    tq_get("UNRATE", get  = "economic.data", from = "1947-01-01", to = "2017-12-31") %>%
                        rename(UR = price) %>%
                        tq_transmute(select = UR, mutate_fun = to.quarterly) %>%
                        mutate(date = as.Date(date)),
                    by = "date") %>%
    dplyr::select(date, dlrGDP, UR)

# plot log change in GDP and unemployment rate
y.tbl %>%
    gather(variable, value, -date) %>%
    ggplot(aes(x = date, y = value)) +
        geom_line() +
        facet_wrap(~variable, ncol = 1, scales = "free_y")

# Blanchard and Quah use 1950Q2 to 1987Q4 as sample, and demean the data
y.ts <- y.tbl %>%
    filter(date >= "1950-04-01", date <= "1987-10-01") %>%
    mutate_at(vars(dlrGDP,UR), funs(. - mean(.))) %>%
    tk_ts(select= c("dlrGDP","UR"), start = 1948, frequency = 4)

# plot log change in GDP and unemployment rate for 1950Q2 to 1987Q4 sample
plot(y.ts)


#### SVAR with long run restrictions ####

# first estimate reduced form VAR
VARselect(y.ts, lag.max = 8)
myVAR <- VAR(y.ts, ic = "SC", lag.max = 8)
summary(myVAR)

# impose Blanchard-Quah long run restriction:
#  row 1 column 2 element of the cumulative effect matrix is going to be restricted to 0
?BQ
mySVAR <- BQ(myVAR)
summary(mySVAR)


#### IRFs ####

# standard non-cumulative IRFs
myIRF <- irf(mySVAR, n.ahead = 40, ci = .9)
# cumulative IRFs
myIRF.c <- irf(mySVAR, n.ahead = 40, ci = .9, cumulative = TRUE)


# arrange IRF data into a tibble to be used with ggplot
# and plot IRFs using ggplot
myIRF.tbl <-
    bind_rows(# standard IRFs for UR
              myIRF[1:3] %>%
                  modify_depth(2, as.tibble) %>%
                  modify_depth(1, bind_rows, .id = "impulse") %>%
                  map_df(bind_rows, .id = "key") %>%
                  dplyr::select(-dlrGDP) %>%
                  gather(response, value, -key, -impulse),
              # cumulative IRFs for GDP
              myIRF.c[1:3] %>%
                  modify_depth(2, as.tibble) %>%
                  modify_depth(1, bind_rows, .id = "impulse") %>%
                  map_df(bind_rows, .id = "key") %>%
                  dplyr::select(-UR) %>%
                  gather(response, value, -key, -impulse)) %>%
    group_by(key, impulse, response) %>%
    mutate(lag = row_number()) %>%
    ungroup() %>%
    # change signs for the non-technology shock IRFs so that they show effects of a positive shock, not a negative one
    mutate(value = if_else(impulse == "UR", -value, value)) %>%
    spread(key, value)

g <- myIRF.tbl %>%
    mutate(impulse.label = case_when(impulse == "dlrGDP" ~ 1,
                                    impulse == "UR"     ~ 2) %>% factor(labels = c("technology shock","non-technology shock")),
           response.label = case_when(response == "dlrGDP" ~ "log(GDP)",
                                      response == "UR" ~ "Unemployment Rate") ) %>%
    ggplot(aes(x = lag, y = irf)) +
        geom_ribbon(aes(x = lag, ymin = Lower, ymax = Upper), fill = "gray50", alpha = .3) +
        geom_line() +
        geom_hline(yintercept = 0, linetype = "dashed") +
        labs(x = "", y = "", title = "SVAR Impulse Response Functions") +
        facet_grid(response.label ~ impulse.label, switch = "y") +
        theme(strip.text.y = element_text(angle = 90))
g

# plot IRFs using plotly
library(plotly)
ggplotly(g)



# note that by construction the contemporaneous impact matrix is identical to the elements of the IRFs for period 0 (impact period)
summary(mySVAR)
myIRF.c$irf[[1]][1,]
myIRF.c$irf[[2]][1,]
# and that the long run impact matrix from is essentially the same as the elements of the IRFs if the horizon is large enough, e.g. 100 periods
myIRF.c <- irf(mySVAR, n.ahead = 100, ci = .9, cumulative = TRUE, boot = FALSE)
myIRF.c$irf[[1]][101,]
myIRF.c$irf[[2]][101,]



# note that there is a bug in vars package - cumulative IRFs are not always constructed correctly if there is only one variable in response
# myIRF.c.1 <- irf(mySVAR, n.ahead=40, ci=.9, cumulative=TRUE, response="dlrGDP")
irf(mySVAR, n.ahead = 4, ci = .9, cumulative = FALSE)$irf
irf(mySVAR, n.ahead = 4, ci = .9, cumulative = FALSE, response = "dlrGDP")$irf
irf(mySVAR, n.ahead = 4, ci = .9, cumulative = TRUE)$irf
irf(mySVAR, n.ahead = 4, ci = .9, cumulative = TRUE, response = "dlrGDP")$irf


#### FEVD ####
mySVAR %>% fevd(n.ahead=40) %>% plot(addbars = 10)

