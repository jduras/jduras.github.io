
# set working directory
# setwd("C:/User/Courses/E5316/Codes")
# setwd("C:/Drive/Dropbox/User/Academic/06TexasTech/02Teaching/06 5316 Time Series Econometrics Spring 2017/Codes")

# import the data on the growth rate of GDP, convert it into time series xts object
#  this data can be downloaded from here
#  http://faculty.chicagobooth.edu/ruey.tsay/teaching/fts3/q-gnp4791.txt

library(magrittr)
library(readr)
library(xts)
library(ggplot2)
library(ggfortify)

y <-
    read_csv(file="http://faculty.chicagobooth.edu/ruey.tsay/teaching/fts3/q-gnp4791.txt", col_names=FALSE) %>%
    ts(start=c(1947,2), frequency=4)

str(y)
head(y)
tail(y)


# plot y using base package
plot(y, xlab="", ylab="")


# plot y using ggplot2 package
autoplot(y)

# set default ggplot theme to theme_bw(), and store the previous one in theme_old
theme_old <- theme_set(theme_bw())

# use pipe operator and modify the plot
autoplot(y) +
    labs(x="", y="", title="Real GNP growth rate")


y %>%
    autoplot() +
    labs(x="", y="", title="Real GNP growth rate")


nlags <- 40

# change the plot window layout to 2 rows and  1 column
par(mfrow=c(2,1))
# plot ACF for y up to lag nlags
acf(y, type="correlation", lag=nlags, main="")
# plot PACF for y up to lag nlags
acf(y, type="partial", lag=nlags, main="")


# plot ACF for y up to lag 24 using ggplot2
y %>%
    as.data.frame() %>%
    acf(type="correlation", lag = nlags, plot = FALSE) %>%
    autoplot() + labs(title="Real GNP growth rate")
# plot PACF for y up to lag 24 using ggplot2
y %>%
    as.data.frame() %>%
    acf(type="partial", lag = nlags, plot = FALSE) %>%
    autoplot() + labs(title="Real GNP growth rate")


# estimate an AR(1) model - there is only one significant coefficient in the PACF plot for y
m1 <- arima(y, order = c(1,0,0))
m1
# show the structure of object m1
str(m1)
# diagnostics for the AR(1) model using ggtsdiag from ggfortify package -  note that there seems to be a problem with remaining serial correlation at lag 2
ggtsdiag(m1, gof.lag = nlags)


# estimate an AR(2) model to deal with the problem of remaining serial correlation at lag 2
m2 <- arima(y, order=c(2,0,0))
m2
# diagnostics for the AR(2) model - note that the problem with remaining serial correlation at lag 2 is gone
ggtsdiag(m2, gof.lag = nlags)


# estimate an AR(3) model since PACF for lag 2 and 3 are comparable in size
m3 <- arima(y, order=c(3,0,0))
m3
# diagnostics for the AR(3) model
ggtsdiag(m3, gof.lag = nlags)

# z-statistics for coefficients of AR(3) model - phi2 is signifficant at 5% level, phi3 is marginally insignifficant
m3$coef/sqrt(diag(m3$var.coef))
# p values
(1-pnorm(abs(m3$coef)/sqrt(diag(m3$var.coef))))*2


# use AIC to choose order p of the AR model
# ar command includes by default a constant in the model, by removing the overall mean of x before fitting the AR model
m <- ar(y, method="mle")
m <- ar(as.vector(y), method="mle")
m
str(m)
# note that AIC prefers AR(3) to AR(2)
m$order
m$aic


# note that BIC prefers AR(2) to AR(3), in general BIC puts a larger penalty on additional coefficients than AIC
BIC(m1)
BIC(m2)
BIC(m3)


# Ljung-Box test - for residuals of a model adjust the degrees of freedom m by subtracting the number of parameters g
# this adjustment will not make a big difference if m is large but matters if m is small

m2.LB.lag8 <- Box.test(m2$residuals, lag=8, type="Ljung")
m2.LB.lag8
1-pchisq(m2.LB.lag8$statistic,5)

m2.LB.lag12 <- Box.test(m2$residuals, lag=12, type="Ljung")
m2.LB.lag12
1-pchisq(m2.LB.lag12$statistic,9)

m2.LB.lag16 <- Box.test(m2$residuals, lag=16, type="Ljung")
m2.LB.lag16
1-pchisq(m2.LB.lag16$statistic,13)

