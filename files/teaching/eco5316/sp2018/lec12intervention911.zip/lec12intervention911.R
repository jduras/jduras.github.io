
library(TSA)
library(zoo)
library(forecast)


# get data on Monthly U.S. airline passenger-miles 01/1996-05/2005
data(airmiles, package="TSA")
str(airmiles)
frequency(airmiles)
index(airmiles)
head(airmiles)
tail(airmiles)

yall <- airmiles

# identify the model for the process over the pre-intervention period
y <- window(yall, end=c(2001,8))

ly <- log(y)
dly1 <-diff(ly)
dly12 <- diff(ly, lag=12)
d2ly1_12 <- diff(diff(ly), lag=12)

par(mfrow=c(2,3))
plot(y, xlab = "", ylab = "", main = 'airmiles')
plot(ly, xlab = "", ylab = "", main = 'log(airmiles)')
plot.new()
plot(dly1, xlab = "", ylab = "", main = expression(paste(Delta, "log(airmiles)")))
plot(dly12, xlab = "", ylab = "", main = expression(paste(Delta[12], "log(airmiles)")))
plot(d2ly1_12, xlab = "", ylab = "", main = expression(paste(Delta,Delta[12], "log(airmiles)")))


library(dygraphs)
dygraph(dly1)


maxlag <- 60

par(mfrow=c(2,4))
Acf(ly, lag.max=maxlag, main = expression(paste("ACF for log(airmiles)")))
Acf(dly1, lag.max=maxlag, main = expression(paste("ACF for ",Delta, "log(airmiles)")))
Acf(dly12, lag.max=maxlag, main = expression(paste("ACF for ",Delta[12], "log(airmiles)")))
Acf(d2ly1_12, lag.max=maxlag, main = expression(paste("ACF for ",Delta,Delta[12], "log(airmiles)")))

Pacf(ly, lag.max = maxlag, main = expression(paste("PACF for log(airmiles)")))
Pacf(dly1, lag.max = maxlag, main = expression(paste("PACF for ",Delta, "log(airmiles)")))
Pacf(dly12, lag.max = maxlag, main = expression(paste("PACF for ",Delta[12], "log(airmiles)")))
Pacf(d2ly1_12, lag.max = maxlag, main = expression(paste("PACF for ",Delta,Delta[12], "log(airmiles)")))

# estimate model for pre-intervention period, based on ACF and PACF using just regular MA(1)
# but note that there are only 68 observation in the pre-intervention sample
# and so the 95% confidence interval is really wide, roughly [-0.25,0.25]
m1 <- Arima(ly, order = c(0,1,1), seasonal = list(order = c(0,1,0)))
m1
tsdiag(m1, gof.lag = maxlag)

# adding seasonal MA(1) lowers both AICc and BIC, S-MA(1) term is significant
m2 <- Arima(ly, order = c(0,1,1), seasonal = list(order = c(0,1,1)))
m2
tsdiag(m2, gof.lag = maxlag)

# forecast based on the model for the pre-intervention period
m2.f <- forecast(m2, 48)
m2.f.err <- log(yall) - m.f$mean

# plot forecast
par(mfrow=c(2,2), mar=c(2,4,2,2), cex=0.9)
plot(m2.f, ylim=c(17,18.5))
lines(log(yall))
plot(m2.f.err, ylim=c(-0.45,0.05), main="Multistep Forecast Error")
abline(h=0, lty="dashed")
Acf(m2.f.err, lag.max = 48, ylab = "ACF", main = "")
Pacf(m2.f.err, lag.max = 48, ylab = "PACF", main = "")



# estimate model with transfer function for the period 1/1996-12/2002
y.2 <- window(yall, end = c(2002,12))


P911 <- 1*(index(y.2)==2001+(9-1)/12)
S911 <- 1*(index(y.2)>=2001+(9-1)/12)

# model with a persistent effect, no permanent effect
m3 <- TSA::arimax(log(y.2), order = c(0,1,1), seasonal = list(order = c(0,1,1), period = 12),
             xtransf = data.frame(P911), transfer = list(c(1,0)), method = "ML")
m3
tsdiag(m3, gof.lag = maxlag)

# model with a transitory and a persistent effect, no permanent effect
m4 <- TSA::arimax(log(y.2), order = c(0,1,1), seasonal = list(order = c(0,1,1), period = 12),
             xtransf = data.frame(P911,P911), transfer = list(c(1,0),c(0,0)), method = "ML")
m4
tsdiag(m4, gof.lag = maxlag)

# model with a persistent effect and a permanent effect
m5 <- arimax(log(y.2), order = c(0,1,1), seasonal = list(order=c(0,1,1), period = 12),
             xtransf = data.frame(P911,S911), transfer = list(c(1,0),c(0,0)), method = "ML")
m5
tsdiag(m5, gof.lag = maxlag)


# note: to introduce a two period delay set MA(s) order of omega(L) to s=2
# and used 'fixed' argument to fix MA(0) and MA(1) coefficients omega0 and omega1 at 0
# m3b <- arimax(log(y.2), order=c(0,1,1), seasonal=list(order=c(0,1,1), period=12),
#             xtransf=data.frame(P911), transfer=list(c(0,2)), method="ML", fixed=c(NA,NA,0,0,NA))
# m3b
# tsdiag(m3b, gof.lag=maxlag)


# half-life of the intervention effect occurs when 1-delta1^{t-t0} = 0.5
# that is when t = t0 + log(0.5)/log(delta1)  or in other words after log(0.5)/log(delta1) periods
# smaller values imply quicker convergence
log(0.5)/log(m3$coef["P911-AR1"])
log(0.5)/log(m4$coef["P911-AR1"])
log(0.5)/log(m5$coef["P911-AR1"])



# construct forecast for the model with transfer function for 2003/01-2002/12
t2 <- length(y.2)
hmax <- 36
P911x <- c(P911, rep(0,hmax))
S911x <- c(S911, rep(1, hmax))

tf3 <- m3$coef["P911-MA0"]*filter(P911x, filter=m3$coef["P911-AR1"], method='recursive', sides=1)
m3x <- Arima(log(y.2), order=c(0,1,1),  seasonal=list(order=c(0,1,1), period=12), xreg=tf3[1:t2])
m3x
m3x.f.h <- forecast(m3x, h=hmax, xreg=tf3[(t2+1):(t2+hmax)])


tf4 <- cbind(m4$coef["P911.1-MA0"]*P911x, m4$coef["P911-MA0"]*filter(P911x, filter=m4$coef["P911-AR1"], method='recursive', sides=1))
m4x <- Arima(log(y.2), order=c(0,1,1),  seasonal=list(order=c(0,1,1), period=12), xreg=tf4[1:t2,])
m4x
m4x.f.h <- forecast(m4x, h=hmax, xreg=tf4[(t2+1):(t2+hmax),])


tf5 <- cbind(m5$coef["S911-MA0"]*S911x, m5$coef["P911-MA0"]*filter(P911x, filter = m5$coef["P911-AR1"], method = 'recursive', sides = 1))
m5x <- Arima(log(y.2), order = c(0,1,1), seasonal = list(order = c(0,1,1), period = 12), xreg = tf5[1:t2,])
m5x
m5x.f.h <- forecast(m5x, h = hmax, xreg = tf5[(t2+1):(t2+hmax),])

# plot forecast for the model with transfer function
par(mfrow=c(3,1))
plot(m3x.f.h)
lines(log(yall))
plot(m4x.f.h)
lines(log(yall))
plot(m5x.f.h)
lines(log(yall))

# construct estimated 9/11 effects on U.S. airline passenger-miles
f3 <- m3$coef["P911-MA0"]*filter(P911x, filter = m3$coef["P911-AR1"], method = "recursive") %>% ts(start = 1996, frequency = 12)
f4 <- m4$coef["P911-MA0"]*P911x + m4$coef["P911-MA0"]*filter(P911x, filter = m4$coef["P911-AR1"], method = "recursive") %>% ts(start = 1996, frequency = 12)
f5 <- m5$coef["S911-MA0"]*S911x + m5$coef["P911-MA0"]*filter(P911x, filter = m5$coef["P911-AR1"], method = "recursive") %>% ts(start = 1996, frequency = 12)

# plot estimated 9/11 effects on U.S. airline passenger-miles
f <- cbind(f3, f4, f5)
par(mfrow = c(1,1))
plot(window(f, start = 2000), plot.type = "single", col = c(4,2,3), lty = c(1,2,3),
     ylab="", main="Estimated effect of 9/11 on U.S. airline passenger-miles, in log points")
legend("bottomright",c("model m3: persistent", "model m4: persistent + transitory", "model m5: persistent + permanent"), bty="n", col=c(4,2,3), lty=c(1,2,3))





# create a one month ahead recursive scheme forecast
yall <- airmiles
fstM <- 1996
lstM <- 2002+11/12
y1 <- window(yall, end = lstM)
y2 <- window(yall, start = lstM+1/12)

m4x.f.rec <- list()
for(i in 1:(length(y2)+1))
{
    y <- window( yall, end=lstM+(i-1)/12 )
    P911 <- 1*(index(y)==2001+(9-1)/12)
    m4.updt <- arimax(log(y), order = c(0,1,1), seasonal = list(order = c(0,1,1), period = 12),
                      xtransf = data.frame(P911, P911), transfer = list(c(1,0), c(0,0)), method="ML")
    P911 <- c(P911,0)
    tf4 <- cbind(m4.updt$coef["P911.1-MA0"]*P911,
                 m4.updt$coef["P911-MA0"]*filter(P911, filter=m4.updt$coef["P911-AR1"], method = "recursive"))
    m4x.updt <- Arima(log(y), order = c(0,1,1), seasonal = list(order = c(0,1,1), period = 12), xreg = tf4[1:length(y),])
    m4x.updt.f.1 <- forecast(m4x.updt, h=1, xreg=t(as.matrix(tf4[(length(y)+1):(length(y)+1),])))
    m4x.f.rec$mean <- rbind(m4x.f.rec$mean, as.zoo(m4x.updt.f.1$mean))
    m4x.f.rec$lower <- rbind(m4x.f.rec$lower, m4x.updt.f.1$lower)
    m4x.f.rec$upper <- rbind(m4x.f.rec$upper, m4x.updt.f.1$upper)
}
m4x.f.rec$mean <- as.ts(m4x.f.rec$mean)
m4x.f.rec$level <- m4x.updt.f.1$level
m4x.f.rec$x <- window(m4x.updt.f.1$x, end=lstM)
class(m4x.f.rec) <- "forecast"

# plot multistep and 1 steap ahead forecasts
par(mfrow = c(2,1), mar = c(2,4,2,2))
# multistep ahead forecasts
plot(m4x.f.h, xlim = c(1996,2006), ylim = c(17,18), main = "Multistep Ahead Forecasts")
lines(log(yall))
# 1 step ahead rolling forecasts form model m4
plot(m4x.f.rec, xlim = c(1996,2006), ylim = c(17,18), main = "1-Month Ahead Recursive Forecasts")
lines(log(yall))


# plot forecast errors for multistep and 1 steap ahead forecast error
par(mfrow = c(2,1), mar = c(2,4,2,2))
# multistep ahead forecasts
plot(log(y2) - m4x.f.h$mean, xlim = c(2003,2005), main = "Forecast Errors: Multistep Ahead Forecasts")
abline(h = 0, lty = "dashed")
# 1 step ahead rolling forecasts form model m4
plot(log(y2) - m4x.f.rec$mean, xlim = c(2003,2005), main = "Forecast Errors: 1-Month Ahead Recursive Forecasts")
abline(h = 0, lty = "dashed")


# evaluate forecast accuracy
accuracy(m4x.f.h$mean, log(y2))
accuracy(m4x.f.rec$mean, log(y2))


# convert from logs back to levels
m4x.f.h.levels <- m4x.f.h
m4x.f.h$mean <- exp(m4x.f.h$mean)
m4x.f.h$lower <- exp(m4x.f.h$lower)
m4x.f.h$upper <- exp(m4x.f.h$upper)
m4x.f.h$x <- exp(m4x.f.h$x)

m4x.f.rec.levels <- m4x.f.rec
m4x.f.rec.levels$mean <- exp(m4x.f.rec$mean)
m4x.f.rec.levels$lower <- exp(m4x.f.rec$lower)
m4x.f.rec.levels$upper <- exp(m4x.f.rec$upper)
m4x.f.rec.levels$x <- exp(m4x.f.rec$x)


# plot forecast in levels
par(mfrow=c(2,1), mar=c(2,4,2,2))
# plot multistep ahead forecasts
plot(m4x.f.h.levels, xlim = c(1996,2006), main="Multistep Ahead Forecasts")
lines(yall)
# plot 1 step ahead rolling forecasts form model m4
plot(m4x.f.h.levels, xlim = c(1996,2006), main = "1-Month Ahead Recursive Forecasts")
lines(yall)



# evaluate forecast accuracy for levels
accuracy(m4x.f.h.levels$mean, y2)
accuracy(m4x.f.rec.levels$mean, y2)



