
rm(list=ls())

library(zoo)
library(magrittr)
library(dplyr)
library(tidyr)
library(timetk)
library(ggplot2)
library(ggfortify)
library(forecast)



#### Data ####

# get data on Monthly U.S. airline passenger-miles 01/1996-05/2005
# construct log, change, log-change, seasonal log change

data(airmiles, package="TSA")

tbl.wide.all <-
    airmiles %>%
    tk_tbl(rename_index = "monyear") %>%
    rename(y = airmiles) %>%
    mutate(ly = log(y),
           dy = y - lag(y),
           dly1 = ly - lag(ly),
           dly12 = ly - lag(ly, 12),
           d2ly12_1 = dly12 - lag(dly12))

# set default theme for ggplot2
theme_set(theme_bw())

# plot time series: levels, logs, differences
tbl.wide.all %>%
    gather(variable, value, -monyear) %>%
    mutate(variable.f = factor(variable, ordered = TRUE,
                               levels = c("y", "ly", "dy", "dly1", "dly12", "d2ly12_1"),
                               labels = c("airmiles", "log(airmiles)",
                                          expression(paste(Delta,"airmiles")),
                                          expression(paste(Delta,"log(airmiles)")),
                                          expression(paste(Delta[12],"log(airmiles)")),
                                          expression(paste(Delta,Delta[12],"log(airmiles)"))))) %>%
    ggplot(aes(x = monyear, y = value)) +
        geom_line() +
        scale_x_yearmon() +
        labs(x = "", y = "") +
        facet_wrap(~variable.f, ncol = 3, scales = "free_y", labeller = label_parsed)

# add pulse and step functions for 9/11
tbl.wide.all <-
    tbl.wide.all %>%
    mutate(P911 = as.integer(monyear == as.yearmon("Sep 2001")),
           S911 = as.integer(monyear >= as.yearmon("Sep 2001")))

# split sample

tbl.wide.1 <- tbl.wide.all %>%
    filter(monyear <= as.yearmon("Aug 2001"))
tbl.wide.2 <- tbl.wide.all %>%
    filter(monyear <= as.yearmon("Dec 2002"))


ly.ts.all <- tbl.wide.all %>%
    tk_ts(select = ly, start = .$monyear[1], frequency = 12)
ly.ts.1 <- tbl.wide.1 %>%
    tk_ts(select = ly, start = .$monyear[1], frequency = 12)
ly.ts.2 <- tbl.wide.2 %>%
    tk_ts(select = ly, start = .$monyear[1], frequency = 12)


#### Pre intervention model - Estimation ####

# identify the model for the process over the pre 9/11 period
par(mfrow=c(3,4))

plot(tbl.wide.1$monyear, tbl.wide.1$ly, type = "l", xlab="", ylab="", main='log(airmiles)')
plot(tbl.wide.1$monyear, tbl.wide.1$dly1, type = "l", xlab="", ylab="", main=expression(paste(Delta, "log(airmiles)")))
plot(tbl.wide.1$monyear, tbl.wide.1$dly12, type = "l", xlab="", ylab="", main=expression(paste(Delta[12], "log(airmiles)")))
plot(tbl.wide.1$monyear, tbl.wide.1$d2ly12_1, type = "l", xlab="", ylab="", main=expression(paste(Delta,Delta[12], "log(airmiles)")))

maxlag <- 60

Acf(tbl.wide.1$ly, lag.max = maxlag, ylab = "", main = expression(paste("ACF for log(airmiles)")))
Acf(tbl.wide.1$dly1, lag.max = maxlag, ylab = "", main = expression(paste("ACF for ", Delta,"log(airmiles)")))
Acf(tbl.wide.1$dly12, lag.max = maxlag, ylab = "", main = expression(paste("ACF for ", Delta[12], "log(airmiles)")))
Acf(tbl.wide.1$d2ly12_1, lag.max = maxlag, ylab = "", main = expression(paste("ACF for ", Delta, Delta[12], "log(airmiles)")))

Pacf(tbl.wide.1$ly, lag.max = maxlag, ylab = "", main = expression(paste("PACF for log(airmiles)")))
Pacf(tbl.wide.1$dly1, lag.max = maxlag, ylab = "", main = expression(paste("PACF for ", Delta, "log(airmiles)")))
Pacf(tbl.wide.1$dly12, lag.max = maxlag, ylab = "", main = expression(paste("PACF for ", Delta[12], "log(airmiles)")))
Pacf(tbl.wide.1$d2ly12_1, lag.max = maxlag, ylab = "", main = expression(paste("PACF for ", Delta,Delta[12], "log(airmiles)")))

# estimate model for pre-intervention period 1996/01-2001/08
# based on ACF and PACF using just regular MA(1)
# note however that there are only 68 observation in the pre-intervention sample
# and so the 95% confidence interval is really wide, roughly [-0.25,0.25]
m1 <- Arima(ly.ts.1, order = c(0,1,1), seasonal = list(order = c(0,1,0)))
m1
tsdiag(m1, gof.lag = maxlag)
TSA::tsdiag.Arima(m1, gof.lag = maxlag, omit.initial = FALSE)
TSA::tsdiag.Arima(m1, gof.lag = maxlag)

# adding seasonal MA(1) lowers both AICc and BIC, S-MA(1) term is significant
m2 <- Arima(ly.ts.1, order = c(0,1,1), seasonal = list(order = c(0,1,1)))
m2
tsdiag(m2, gof.lag=maxlag)
TSA::tsdiag.Arima(m2, gof.lag = maxlag, omit.initial = FALSE)
TSA::tsdiag.Arima(m2, gof.lag = maxlag)


#### Pre intervention model - Multistep Forecast ####

# forecast for 2001/09-2005/08 based on the model for the pre-intervention period  1996/01-2001/08
m2.f <- forecast(m2, 48)
m2.f.err <- ly.ts.all - m2.f$mean

# plot the forecast and the forecast error
# based on the ACF and PACF for the forecast error the intervention component can be introduced as an AR(1) process
par(mfrow = c(2,2), mar = c(2,4,2,2), cex = 0.9)
plot(m2.f, ylim = c(17,18.5))
lines(ly.ts.all)
plot(m2.f.err, ylim = c(-0.45,0.05), main = "Multistep Forecast Error")
abline(h=0, lty="dashed")
Acf(m2.f.err, lag.max = 48, ylab = "ACF", main = "")
Pacf(m2.f.err, lag.max = 48, ylab = "PACF", main = "")


#### Model with intervention - Estimation ####

# this is arimax from TSA, with filter in lines 105, 107, 109 changed to stats:::filter to be able to use dplyr together with arimax
source("arimaxX.R")

# estimate the model again, this time foir the period 1996/01-2002/12 so including the post 9/11 period
P911 <- tbl.wide.2$P911
S911 <- tbl.wide.2$S911

# model with a persistent effect, no permanent effect
m3 <- arimaxX(ly.ts.2, order = c(0,1,1), seasonal = list(order = c(0,1,1), period = 12),
             xtransf = data.frame(P911), transfer = list(c(1,0)), method = "ML")
m3
ggtsdiag(m3, gof.lag = maxlag)

# model with a transitory and a persistent effect, no permanent effect
m4 <- arimaxX(ly.ts.2, order = c(0,1,1), seasonal = list(order = c(0,1,1), period = 12),
             xtransf = data.frame(P911, P911), transfer = list(c(1,0), c(0,0)), method="ML")
m4
ggtsdiag(m4, gof.lag = maxlag)

# model with a persistent effect and a permanent effect
m5 <- arimaxX(ly.ts.2, order = c(0,1,1), seasonal = list(order = c(0,1,1), period = 12),
                  xtransf = data.frame(P911, S911), transfer = list(c(1,0), c(0,0)), method = "ML")
m5
ggtsdiag(m5, gof.lag = maxlag)


# construct estimated 9/11 effects on U.S. airline passenger-miles
f3 <- m3$coef["P911-MA0"] *( stats::filter(P911x, filter = m3$coef["P911-AR1"], method = "recursive") ) %>% ts(start = 1996, frequency = 12)
f4 <- m4$coef["P911.1-MA0"]*P911x + m4$coef["P911-MA0"] *( stats::filter(P911x, filter = m4$coef["P911-AR1"], method = "recursive") ) %>% ts(start = 1996, frequency = 12)
f5 <- m5$coef["S911-MA0"]*S911x + m5$coef["P911-MA0"] *( stats::filter(P911x, filter = m5$coef["P911-AR1"], method = "recursive") ) %>% ts(start = 1996, frequency = 12)

# plot estimated 9/11 effects on U.S. airline passenger-miles
f <- cbind(f3, f4, f5)
par(mfrow = c(1,1))
plot(window(f, start = 2000), plot.type = "single", col = c(4,2,3), lty = c(1,2,3),
     ylab="", main="Estimated effect of 9/11 on U.S. airline passenger-miles, in log points")
legend("bottomright",c("model m3: persistent", "model m4: persistent + transitory", "model m5: persistent + permanent"), bty="n", col=c(4,2,3), lty=c(1,2,3))



# note: to introduce a two period delay set MA(s) order of omega(L) to s=2
# and used 'fixed' argument to fix MA(0) and MA(1) coefficients omega0 and omega1 at 0
# m3b <- arimax(ly.ts.2, order = c(0,1,1), seasonal = list(order = c(0,1,1), period = 12),
#             xtransf = data.frame(P911), transfer = list(c(0,2)), method = "ML", fixed = c(NA,NA,0,0,NA))
# m3b
# tsdiag(m3b, gof.lag = maxlag)


# half-life of the intervention effect occurs when 1-delta1^{t-t0} = 0.5
# that is when t = t0 + log(0.5)/log(delta1)  or in other words after log(0.5)/log(delta1) periods
# smaller values imply quicker convergence
log(0.5)/log(m3$coef["P911-AR1"])
log(0.5)/log(m4$coef["P911-AR1"])
log(0.5)/log(m5$coef["P911-AR1"])


#### Model with intervention - Multistep Forecast ####

# construct forecast for the model with transfer function for 2003/01-2002/12
t2 <- length(ly.ts.2)
hmax <- 30
P911x <- c(P911, rep(0, hmax))
S911x <- c(S911, rep(1, hmax))

# to construct forecast for the model with transfer function we reestimmate models specified ub m3, m4 m5 above using Arima from forecast package

tf3 <- m3$coef["P911-MA0"] *( stats::filter(P911x, filter = m3$coef["P911-AR1"], method='recursive', sides = 1) )
m3x <- Arima(ly.ts.2, order = c(0,1,1), seasonal = list(order = c(0,1,1), period = 12), xreg = tf3[1:t2])
m3x
m3x.f.h <- forecast(m3x, h = hmax, xreg = tf3[(t2+1):(t2+hmax)])

tf4 <- cbind(m4$coef["P911.1-MA0"]*P911x, m4$coef["P911-MA0"] *( stats::filter(P911x, filter = m4$coef["P911-AR1"], method='recursive', sides = 1)) )
m4x <- Arima(ly.ts.2, order = c(0,1,1), seasonal = list(order = c(0,1,1), period = 12), xreg = tf4[1:t2,])
m4x
m4x.f.h <- forecast(m4x, h = hmax, xreg = tf4[(t2+1):(t2+hmax),])

tf5 <- cbind(m5$coef["S911-MA0"]*S911x, m5$coef["P911-MA0"] *( stats::filter(P911x, filter = m5$coef["P911-AR1"], method = 'recursive', sides = 1)) )
m5x <- Arima(ly.ts.2, order = c(0,1,1), seasonal = list(order = c(0,1,1), period = 12), xreg = tf5[1:t2,])
m5x
m5x.f.h <- forecast(m5x, h = hmax, xreg = tf5[(t2+1):(t2+hmax),])

# m4 model has lowest RMSE in the test set
accuracy(m3x.f.h, ly.ts.all)
accuracy(m4x.f.h, ly.ts.all)
accuracy(m5x.f.h, ly.ts.all)

# plot forecast for the models with transfer function
par(mfrow = c(3,1))
plot(m3x.f.h)
lines(ly.ts.all)
plot(m4x.f.h)
lines(ly.ts.all)
plot(m5x.f.h)
lines(ly.ts.all)


#### Model with intervention - Rolling Forecast ####

# create a one month ahead rolling scheme forecast
library(dplyr)
library(purrr)
library(tibbletime)
library(lubridate)
library(broom)
library(sweep)

# window length for rolling SARIMA
window.length <- nrow(tbl.wide.2)
# create rolling SARIMAX function with rollify from tibbletime package
# as before, a modified version of arimax from TSA is used, with filter in lines 105, 107, 109 changed to stats:::filter to be able to use dplyr and tibbletime together with arimax
roll_arimaX <- rollify(function(y, x1, x2) {
                                        x <- cbind(x1, x2)
                                        m <- arimaxX(y, order = c(0,1,1), seasonal = list(order = c(0,1,1), period = 12),
                                                 xtransf = x, transfer=list(c(1,0), c(0,0)))
                                        t2 <- nrow(x)
                                        x <- rbind(x, x[t2,])
                                        # tx <- m$coef["T1-MA0"] *(stats::filter(x, filter = m$coef["T1-AR1"], method = "recursive", sides = 1))
                                        tx <- cbind(m$coef["x2-MA0"]*x[,2], m$coef["x1-MA0"] *(stats::filter(x[,1], filter = m$coef["x1-AR1"], method = "recursive", sides = 1)))
                                        mx <- Arima(y, order = c(0,1,1), seasonal = list(order = c(0,1,1), period = 12), xreg = tx[1:t2,])
                                        mx.f <- forecast(mx, h = 1, xreg = tx[t2+1, , drop = FALSE])

                                        out <- list()

                                        out$y <- y
                                        out$x <- x
                                        out$tx <- tx

                                        out$m <- m
                                        out$mx <- mx
                                        out$mx.f <- mx.f

                                        return(out)},
                        window = window.length, unlist = FALSE)


# estimate rolling SARIMAX m4 model, create 1 step ahead forecasts
results <-
    tbl.wide.all %>%
    mutate(date = as.Date(monyear)) %>%
    as_tbl_time(index = date) %>%
    mutate(arimax.out = roll_arimaX(ly, P911, P911)) %>%
    filter(!is.na(arimax.out)) %>%                         # remove periods at the beginning of sample where model could not be estimated due to lack of data,
    mutate(arimax.out.coefs = map(arimax.out, ~tidy(.x$m, conf.int = TRUE)),
           arimax.out.fcsts = map(arimax.out, ~sw_sweep(.x$mx.f)))

# plot estimated coefficients with confidence intervals
results %>%
    select(date, arimax.out.coefs) %>%
    unnest(arimax.out.coefs) %>%
    ggplot(aes_(x = ~date, y = ~estimate, group = ~term)) +
        geom_line(color = "royalblue") +
        geom_ribbon(aes(x = date, ymin = conf.low, ymax = conf.high), alpha = 0.5, fill = "lightblue") +
        geom_hline(yintercept = 0, color = "black")+
        labs(x = "", y = "", title = "Coefficient estimates", subtitle = paste(window.length, "month rolling window regressions"))+
        theme_minimal() +
        facet_wrap(~term, scales = "free_y")

# extract the 1 period ahead rolling forecasts, convert to levels
m4.f.1.rol <-
    results %>%
    select(date, arimax.out.fcsts) %>%
    unnest(arimax.out.fcsts) %>%
    filter(key == "forecast") %>%
    mutate(date = date %m+% months(1)) %>%
    mutate_at(vars(value, lo.80, lo.95, hi.80, hi.95), funs(exp)) %>%
    rename(y = value) %>%
    select(date, key, y, lo.80, lo.95, hi.80, hi.95)


# actual data & forecast in a single tibble
tbl.f.1.rol <- bind_rows(tbl.wide.all %>%
                             select(monyear, y) %>%
                             mutate(key = "actual",
                                    date = as.Date(monyear)) %>%
                             select(date, key, y),
                         m4.f.1.rol)

# plot 1-quarter ahead rolling forecasts - levels
tbl.f.1.rol %>%
    ggplot(aes(x = date, y = y, col = key, linetype = key)) +
        geom_ribbon(aes(ymin = lo.95, ymax = hi.95), linetype = "blank", fill = "blue", alpha = 0.1) +
        geom_ribbon(aes(ymin = lo.80, ymax = hi.80), linetype = "blank", fill = "blue", alpha = 0.2) +
        geom_line() +
        geom_point() +
        scale_color_manual(values = c("black","darkblue")) +
        # scale_linetype_manual(values = c("dashed","solid")) +
        labs(x = "", y = "",
             title = "Monthly Airline Passenger-Miles in the US: 1-Step Ahead Rolling Forecast") +
        theme(legend.position = "none")


#### Model with intervention - Forecast Accuracy ####

# evaluate accuracy of forecasts - multistep forecast - logs
accuracy(m4x.f.h$mean, ly.ts.all)
# evaluate accuracy of forecasts - 1 step ahead rolling scheme forecast - logs
accuracy(log(m4.f.1.rol %>% tk_ts(select = y, start = as.yearmon(.$date[1]), frequency = 12)), ly.ts.all)

# evaluate accuracy of forecasts - multistep forecast - levels
accuracy(exp(m4x.f.h$mean), exp(ly.ts.all))
# evaluate accuracy of forecasts - 1 step ahead rolling scheme forecast - levels
accuracy(m4.f.1.rol %>% tk_ts(select = y, start = as.yearmon(.$date[1]), frequency = 12), exp(ly.ts.all))
