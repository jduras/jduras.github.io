
library(ggplot2)
library(ggfortify)


# Quandl package
library(Quandl)

# set Quandl key, see https://docs.quandl.com/docs#section-authentication for details
# Quandl.api_key()

# basic usage example: import real GDP from FRED database
#  https://www.quandl.com/data/FRED/GDPC1-Real-Gross-Domestic-Product-1-Decimal
#  https://research.stlouisfed.org/fred2/series/GDPC1
rGDP <- Quandl("FRED/GDPC1")

str(rGDP)


# you can provide several options, for example
# - specify data format: ts, xts, zoo, df
# - specify start_date and end_date for the time range to load (format date as: yyyy-mm-dd)
rGDP <- Quandl("FRED/GDPC1", type="ts", start_date="2008-1-1", end_date="2017-12-31")

str(rGDP)
autoplot(rGDP)


# if you use vector as an input Quandl organizes data in a wide dataframe
ur.TX <- Quandl(c("FRED/TXUR","FRED/TXURN"))
str(ur.TX)


# tidyquant package
# https://cran.r-project.org/web/packages/tidyquant/vignettes/TQ00-introduction-to-tidyquant.html
library(tidyquant)
library(magrittr)

# set Quandl key, see https://docs.quandl.com/docs#section-authentication for details
# quandl_api_key()

# to get data from FRED specify set the get option to "economic.data"
WTI <- tq_get("DCOILWTICO", get = "economic.data")

# to get data from Quandl specify set the get option to "quandl"
FANG <- c("WIKI/FB", "WIKI/AAPL","WIKI/NFLX","WIKI/GOOG") %>%
    tq_get(get  = "quandl")

# tq_get organizes data in a long dataframe, unlike Quandl
ur.TX <- tq_get(c("FRED/TXUR","FRED/TXURN"), get  = "quandl")
str(ur.TX)

# note that tq_get does not always get alll the data that is available, so it is important to specify the from and to options
ur.TX <- tq_get(c("TXUR","TXURN"), get  = "economic.data")
str(ur.TX)
ur.TX <- tq_get(c("TXUR","TXURN"), get  = "economic.data", from = "1976-01-01", to = "2017-12-31")
str(ur.TX)

# by default the get option in tq_get is set to "stock.prices", and tq_get downloads the
# open, high, low, close, volume and adjusted stock prices for a stock symbol from Yahoo Finance
DJI_SP500 <- c("^DJI","^GSPC") %>%
    tq_get()

str(DJI_SP500)

DJI_SP500 %>%
    ggplot(aes(x = date, y = close, col= symbol)) +
        geom_line() +
        labs(x = "", y = "Closing Price", title = "Dow Jones Industrial Average (^DJI) and S&P 500 (^GSPC)") +
        facet_wrap(~ symbol, scales = "free_y", ncol = 1) +
        theme_bw()
