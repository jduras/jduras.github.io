
library(Quandl)
library(magrittr)
library(ggplot2)
library(ggfortify)
library(forecast)

# set default ggplot theme to theme_bw(), and store the previous one in theme_old
theme_old <- theme_set(theme_bw())

Quandl.api_key('DLk9RQrfTVkD4UTKc7op')

# quarterly Total Wages and Salaries in Texas, Thousands of Dollars, Seasonally Adjusted Annual Rate
y <- Quandl("FRED/TXWTOT", start = "1980-01-01", end = "2016-07-01", type = "ts")

str(y)

autoplot(y)

# log change, a stationary transformation
dly <- diff(log(y))

autoplot(dly) +
    geom_hline(yintercept = 0, linetype="dotted") +
    labs(x = "", y = "", title = "Total Wages and Salaries in Texas, Log Change, Seasonally Adjusted Annual Rate")

# number of lags for ACF and PACF plots
nlags <- 24

# Acf from forecast package is similar to acf from base package but excludes zero lag
# you can use Acf in combination with autoplot from ggfortify
ggAcf(dly, lag.max = nlags)
ggPacf(dly, lag.max = nlags)


# Arima from forecast package is similar to arima from base package but provides BIC and AICc, not just AIC
# AICc is AIC with a correction for finite sample sizes; for a  univariate linear model with normal residuals
# AICc = AIC + 2(g+1)(g+2)/(T-g-2)

m1 <- Arima(dly, order=c(0,0,2))
m1
ggtsdiag(m1, gof.lag = nlags)

m2 <- Arima(dly, order=c(2,0,0))
m2
ggtsdiag(m2, gof.lag = nlags)


# z-statistics for coefficients of AR(2) model - phi1 is not signifficant at any level
m2$coef/sqrt(diag(m2$var.coef))
# p values
(1-pnorm(abs(m2$coef)/sqrt(diag(m2$var.coef))))*2


# estimate ARMA model with a restriction on a parameter
m2.rest <- Arima(dly, order=c(2,0,0), fixed=c(0,NA,NA))
m2.rest
ggtsdiag(m2.rest, gof.lag = nlags)

# find the best ARIMA model based on either AIC, AICc or BIC
m3 <- auto.arima(dly, ic="aicc", seasonal=FALSE, stationary=TRUE)
m3
ggtsdiag(m3, gof.lag = nlags)

m4 <- auto.arima(dly, ic="aicc", seasonal=FALSE, stationary=TRUE, stepwise=FALSE, approximation=FALSE)
m4
ggtsdiag(m4, gof.lag = nlags)



# check stationarity and invertibility of the estimated model - plot inverse AR and MA roots
plot(m4)

