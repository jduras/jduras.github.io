
library(readr)
library(dplyr)
library(tidyr)
library(purrr)
library(ggplot2)
library(ggfortify)
library(zoo)
library(timetk)
library(tibbletime)
library(lubridate)
library(forecast)
library(broom)
library(sweep)


# import the data on earnings per share for Johnson and Johnson,
# then construct log, change, log-change, seasonal log change
tbl.wide.all <-
    read_table("http://faculty.chicagobooth.edu/ruey.tsay/teaching/fts3/q-jnj.txt", col_names = "y") %>%
    ts(start=c(1960,1), frequency=4) %>%
    tk_tbl() %>%
    mutate(ly = log(y),
           dy = y - lag(y),
           dly1 = ly - lag(ly),
           dly4 = ly - lag(ly, 4),
           d2ly4_1 = dly4 - lag(dly4))

# split sample into two parts - estimation sample and prediction sample
fstQ <- 1960.00  # 1960Q1
lstQ <- 1978.75  # 1978Q4
tbl.wide.1 <- tbl.wide.all %>%
    filter(index <= as.yearqtr(lstQ))


# set default theme for ggplot2
theme_set(theme_bw())

# plot time series: levels, logs, differences
tbl.wide.all %>%
    gather(variable, value, -index) %>%
    # mutate(variable.f = factor(variable, ordered = TRUE,
    #                            levels = c("y", "ly", "dy", "dly1", "dly4", "d2ly4_1"))) %>%
    mutate(variable.f = factor(variable, ordered = TRUE,
                               levels = c("y", "ly", "dy", "dly1", "dly4", "d2ly4_1"),
                               labels = c("y", "log(y)",
                                          expression(paste(Delta,"y")),
                                          expression(paste(Delta,"log(y)")),
                                          expression(paste(Delta[4],"log(y)")),
                                          expression(paste(Delta,Delta[4],"log(y)"))))) %>%
    ggplot(aes(x = index, y = value)) +
    geom_hline(aes(yintercept = 0), linetype = "dotted") +
    geom_line() +
    scale_x_yearmon() +
    labs(x = "", y = "") +
    # facet_wrap(~variable.f, ncol = 3, scales = "free_y")
    facet_wrap(~variable.f, ncol = 3, scales = "free_y", labeller = label_parsed)


# plot ACF and PACF
maxlag <-24
par(mfrow=c(2,4))

Acf(tbl.wide.1$ly, type="correlation", lag.max = maxlag, ylab = "", main = expression(paste("ACF for log(y)")))
Acf(tbl.wide.1$dly1, type="correlation", lag.max = maxlag, ylab = "", main = expression(paste("ACF for ", Delta,"log(y)")))
Acf(tbl.wide.1$dly4, type="correlation", lag.max = maxlag, ylab = "", main = expression(paste("ACF for ", Delta[4], "log(y)")))
Acf(tbl.wide.1$d2ly4_1, type="correlation", lag.max = maxlag, ylab = "", main = expression(paste("ACF for ", Delta, Delta[4], "log(y)")))
Acf(tbl.wide.1$ly, type="partial", lag.max = maxlag, ylab = "", main = expression(paste("PACF for log(y)")))
Acf(tbl.wide.1$dly1, type="partial", lag.max = maxlag, ylab = "", main = expression(paste("PACF for ", Delta, "log(y)")))
Acf(tbl.wide.1$dly4, type="partial", lag.max = maxlag, ylab = "", main = expression(paste("PACF for ", Delta[4], "log(y)")))
Acf(tbl.wide.1$d2ly4_1, type="partial", lag.max = maxlag, ylab = "", main = expression(paste("PACF for ", Delta,Delta[4], "log(y)")))


# search for best model using AICc criteria

# this is not correct - tbl.wide.1$ly is not a ts object so auto.arima does not know its frequency
auto.arima(tbl.wide.1$ly, ic = "aicc", d = 1, D = 1, seasonal = TRUE, stationary = FALSE, stepwise = FALSE, approximation = FALSE)

# tbl.wide.1$ly can be first converted to ts using tk_ts before passing it on to auto.arima
tbl.wide.1 %>%
    tk_ts(select = ly, start = fstQ, frequency = 4) %>%
    auto.arima(ic = "aicc", d = 1, D = 1, seasonal = TRUE, stationary = FALSE, stepwise = FALSE, approximation = FALSE)
tbl.wide.1 %>%
    tk_ts(select = ly, start = fstQ, frequency = 4) %>%
    auto.arima(ic = "aicc", d = 1, seasonal = TRUE, stationary = FALSE, stepwise = FALSE, approximation = FALSE)
tbl.wide.1 %>%
    tk_ts(select = ly, start = fstQ, frequency = 4) %>%
    auto.arima(ic = "aicc", seasonal = TRUE, stationary = FALSE, stepwise = FALSE, approximation = FALSE)


# estimate model - twice differenced series, ARIMA(0,1,1)(0,1,1)_4 which is suboptimal based on AICc and BIC, but it is the one used in Tsay's textbook
m1 <- tbl.wide.1 %>%
    tk_ts(select = ly, start = fstQ, frequency = 4) %>%
    Arima(order = c(0,1,1), seasonal = list(order = c(0,1,1), period = 4))
m1
ggtsdiag(m1, gof.lag = maxlag)


# construct 1-quarter to 12-quarters ahead forecasts
hmax <- 12
m1.f.1.to.hmax <- forecast(m1, hmax)

# plot 1-quarter to 12-quarters ahead forecasts - logs
autoplot(m1.f.1.to.hmax) +
    labs(x = "", y = "",
         title = "Log of Earnings per share for Johnson and Johnson: Multistep Forecast")

# actual data
tbl.2 <-
    tbl.wide.all %>%
    select(index, y) %>%
    mutate(key = "actual",
           date = as.Date(index)) %>%
    select(date, key, y)

# extract the multistep forecasts, convert to levels
tbl.f.1.to.hmax <-
    m1.f.1.to.hmax %>%
    sw_sweep() %>%
    filter(key == "forecast") %>%
    mutate_at(vars(ly, lo.80, lo.95, hi.80, hi.95), funs(exp)) %>%
    mutate(date = as.Date(index)) %>%
    rename(y = ly) %>%
    select(date, key, y, lo.80, lo.95, hi.80, hi.95)

# forecast & actual data in a single tibble
tbl.f.1.to.hmax <- bind_rows(tbl.2, tbl.f.1.to.hmax)

# plot 1-quarter to 12-quarters ahead forecasts - levels
tbl.f.1.to.hmax %>%
    filter(date >= "1970-01-01") %>%
    ggplot(aes(x = date, y = y, col = key, linetype = key)) +
    geom_ribbon(aes(ymin = lo.95, ymax = hi.95), linetype = "blank", fill = "blue", alpha = 0.1) +
    geom_ribbon(aes(ymin = lo.80, ymax = hi.80), linetype = "blank", fill = "blue", alpha = 0.2) +
    geom_line() +
    geom_point() +
    scale_color_manual(values = c("black","darkblue")) +
    scale_linetype_manual(values = c("dashed","solid")) +
    labs(x = "", y = "",
         title = "Earnings per share for Johnson and Johnson: Multistep Forecast") +
    theme(legend.position = "none")


# window length for rolling SARIMA
window.length <- nrow(tbl.wide.1)
# create rolling SARIMA function with rollify from tibbletime package
# here period needs to be specified, since rolling_sarima will be applied on an object that is not in ts format
roll_sarima <- rollify(~Arima(.x, order = c(0,1,1), seasonal = list(order = c(0,1,1), period = 4)),
                      window = window.length, unlist = FALSE)

# estimate rolling SARIMA model, create 1 step ahead forecasts
results <-
    tbl.wide.all %>%
    mutate(date = as.Date(index)) %>%
    as_tbl_time(index = date) %>%                           # covert to tibbletime
    mutate(sarima.model = roll_sarima(ly)) %>%              # estimate models
    filter(!is.na(sarima.model)) %>%                        # remove periods at the beginning of sample where model could not be estimated due to lack of data,
    mutate(sarima.coefs = map(sarima.model, tidy, conf.int = TRUE),
           sarima.fcst = map(sarima.model, (. %>% forecast(1) %>% sw_sweep())))

# plot estimated coefficients with confidence intervals
results %>%
    select(date, sarima.coefs) %>%
    unnest(sarima.coefs) %>%
    ggplot(aes_(x = ~date, y = ~estimate, group = ~term)) +
    geom_line(color = "royalblue") +
    geom_ribbon(aes(x = date, ymin = conf.low, ymax = conf.high), alpha = 0.5, fill = "lightblue") +
    geom_hline(yintercept = 0, color = "black")+
    labs(x = "", y = "",
         title = "Coefficient estimates",
         subtitle = paste(window.length, "month rolling window model"))+
    theme_minimal() +
    facet_wrap(~term, scales = "free_y")

# extract the 1 period ahead rolling forecasts, convert to levels
m1.f.1.rol <-
    results %>%
    select(date, sarima.fcst) %>%
    unnest(sarima.fcst) %>%
    filter(key == "forecast") %>%
    mutate(date = date %m+% months(3)) %>%
    mutate_at(vars(value, lo.80, lo.95, hi.80, hi.95), funs(exp)) %>%
    rename(y = value) %>%
    select(date, key, y, lo.80, lo.95, hi.80, hi.95)

# forecast & actual data in a single tibble
tbl.f.1.rol <- bind_rows(tbl.2, m1.f.1.rol)

# plot 1-quarter ahead rolling forecasts - levels
tbl.f.1.rol %>%
    filter(date >= "1970-01-01") %>%
    ggplot(aes(x = date, y = y, col = key, linetype = key)) +
    geom_ribbon(aes(ymin = lo.95, ymax = hi.95), linetype = "blank", fill = "blue", alpha = 0.1) +
    geom_ribbon(aes(ymin = lo.80, ymax = hi.80), linetype = "blank", fill = "blue", alpha = 0.2) +
    geom_line() +
    geom_point() +
    scale_color_manual(values = c("black","darkblue")) +
    scale_linetype_manual(values = c("dashed","solid")) +
    labs(x = "", y = "",
         title = "Earnings per share for Johnson and Johnson: 1-Step Ahead Rolling Forecast") +
    theme(legend.position = "none")



# convert actual data in prediction sample into ts format
y.ts.2 <- tbl.wide.all %>%
    filter(index > as.yearqtr(lstQ)) %>%
    tk_ts(select = y, start = lstQ+0.25, frequency = 4)

# evaluate accuracy of forecasts - multistep forecast - logs
accuracy(m1.f.1.to.hmax$mean, log(y.ts.2))
# evaluate accuracy of forecasts - 1 step ahead rolling scheme forecast - logs
accuracy(log(m1.f.1.rol$y), log(y.ts.2))

# evaluate accuracy of forecasts - multistep forecast - levels
accuracy(exp(m1.f.1.to.hmax$mean), y.ts.2)
# evaluate accuracy of forecasts - 1 step ahead rolling scheme forecast - levels
accuracy(m1.f.1.rol$y, y.ts.2)
