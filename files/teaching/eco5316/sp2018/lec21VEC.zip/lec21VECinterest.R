
# example of VEC - long run and short run interest rate, Enders p. 397

# remove all objects from workspace
rm(list=ls())

# load packages
library(readr)
library(magrittr)
library(dplyr)
library(tidyr)
library(purrr)
library(broom)
library(timetk)
library(tibbletime)
library(tidyquant)
library(zoo)
library(lubridate)
library(urca)
library(vars)
library(ggplot2)
library(ggfortify)

# set default theme for ggplot2
theme_set(theme_bw())


### Data ###

# data from Enders, import quarterly macrodata for U.S., extract 5-year interest rate and 3 month Treasury bill
r.tbl <-
    read_tsv("quarterly.txt") %>%
    mutate(qtryear = as.yearqtr(DATE, format = "%YQ%q")) %>%
    dplyr::select(qtryear, r5, Tbill)
r.tbl

# FRED data
r.tbl <-
    tq_get(c("GS5", "TB3MS"), get = "economic.data",
           from = "1960-01-01", to = "2017-12-31") %>%
    mutate(qtryear = as.yearqtr(date, format = "%Y-%m-%d")) %>%
    group_by(symbol, qtryear) %>%
    summarise_at("price", mean) %>%
    ungroup() %>%
    spread(symbol, price) %>%
    rename(r5 = GS5,
           Tbill = TB3MS)
r.tbl

# convert data into a zoo
# everything works with zoo, except for autoplot of VAR model forecast and autoplot of data with facets = FALSE
r.zoo <-
    r.tbl %>%
    dplyr::filter(qtryear <= as.yearqtr("2012 Q4")) %>%
    tk_zoo(select = -qtryear, date_var = qtryear)

# convert data into a ts
r.ts <-
    r.tbl %>%
    dplyr::filter(qtryear <= as.yearqtr("2012 Q4")) %>%
    tk_ts(select = -qtryear, start = year(.$qtryear[1]), frequency = 4)

# plot data
autoplot(r.ts)
autoplot(r.ts, facets = FALSE)

r.tbl %>%
    gather(variable, value, -qtryear) %>%
    mutate(variable.label = case_when(variable == "r5" ~ "5-year interest rate",
                                      variable == "Tbill" ~ "3 month Treasury bill rate")) %>%
    ggplot(aes(x = qtryear, y = value, col = variable.label)) +
    geom_line() +
    scale_x_yearqtr() +
    labs(x = "", y = "", col = "")


# lm(r.ts[,1] ~ r.ts[,2]) %>% summary()
# lm(r.ts[,2] ~ r.ts[,1]) %>% summary()

VARselect(r.ts, type = "const", lag.max = 12)


#### Cointegration test - Johansen's methodology ###

r.CA <- ca.jo(r.ts, type = "eigen", ecdet = "const", K = 2, spec = "transitory")
summary(r.CA)
r.CA <- ca.jo(r.ts, type = "trace", ecdet = "const", K = 2, spec = "transitory")
summary(r.CA)

# test for the presence of the constant term in the cointegration relationship
lttest(r.CA, r = 1)



#### Vector Error Correction Model ###

# unrestricted VEC
r.VEC <- cajorls(r.CA, r = 1)
r.VEC
summary(r.VEC$rlm)

# r.VEC$beta
# r.VEC$rlm$coefficients

# test restriction on betta
rest.betta <- matrix(data = c(1,-1,0,0,0,1) , nrow = 3, ncol = 2)
r.CA.rest <- blrtest(r.CA, H = rest.betta, r = 1)
summary(r.CA.rest)

# VEC with restriction on betta
r.VEC.rest <- cajorls(r.CA.rest, r = 1)
r.VEC.rest
summary(r.VEC.rest$rlm)



#### Vector Error Correction Model: Forecast ###

# transform VEC to VAR
r.VAR <- vec2var(r.CA, r = 1)
source("vec2varX.r")
r.VAR <- vec2varX(r.CA, r = 1)
r.VAR.rbetta <- vec2varX(r.CA, H = rest.betta, r = 1)

r.VAR.fcst <- predict(r.VAR, n.ahead = 8)
r.VAR.rbetta.fcst <- predict(r.VAR.rbetta, n.ahead = 8)

# plot forecast
par(mar = c(4,4,2,1), cex = 0.75)
plot(r.VAR.fcst)
plot(r.VAR.rbetta.fcst)

autoplot(r.VAR.fcst)
autoplot(r.VAR.rbetta.fcst)



#### Vector Error Correction Model: Rolling Estimation ###

# define rolling version of a function that tests for cointegration
window.length <- nrow(r.ts)
roll_CA <-
    rollify(
        function(r5, Tbill) {
            cbind(r5, Tbill) %>% ca.jo(type = "eigen", ecdet = "const", K = 2, spec = "transitory")
        },
        window = window.length, unlist = FALSE)

# rolling estimation
results <-
    r.tbl %>%
    mutate(date = as.Date(qtryear)) %>%
    tbl_time(index = date) %>%
    mutate(CA = roll_CA(r5, Tbill)) %>%
    filter(!is.na(CA)) %>%
    mutate(VEC = map(CA, . %>% cajorls(r = 1)),                                                                       # unrestricted VEC
           CA.rest = map(CA, . %>% blrtest(H = matrix(data = c(1,-1,0,0,0,1) , nrow = 3, ncol = 2), r = 1)),          # test restriction on betta
           VEC.rest = map(CA.rest, cajorls),                                                                          # VEC with alpha2 = 0
           VAR = map(CA, . %>% vec2var(r = 1)),                                                                       # convert VEC to VAR in levels
           VAR.f = map(VAR, . %>% predict(n.ahead = 1) %$% fcst %>% map(as.tibble) %>% bind_rows(.id = "variable"))   # one step ahead forecast
    )
results

# plot statistic for cointegration test
results %>%
    mutate(CA.test = map(CA, ~cbind(teststat = .@teststat, .@cval) %>% tidy())) %>%
    dplyr::select(date, CA.test) %>%
    unnest() %>%
    gather(key, value, -date, -.rownames) %>%
    mutate(rank = str_sub(.rownames, 1, -3) %>% factor(levels = c("r = 0 ", "r <= 1"), ordered = TRUE),
           key = case_when(key == "X10pct" ~ "10%",
                           key == "X5pct" ~ " 5%",
                           key == "X1pct" ~ " 1%",
                           key == "teststat" ~ "test statistic")) %>%
    ggplot(aes(x = date, y = value, col = key)) +
        geom_line() +
        scale_color_manual(values = c("gray10","gray40","gray70","blue")) +
        labs(x = "", y = "", col = "",
             title = "Cointegration test: critical values and test statistic",
             subtitle = paste(window.length, "quarters rolling window")) +
        facet_wrap(~ rank, scales = "free_y")

# plot estimated beta2
results %>%
    mutate(VEC.beta = map(VEC, . %$% beta %>% tidy())) %>%
    dplyr::select(date, VEC.beta) %>%
    unnest() %>%
    filter(.rownames == "Tbill.l1") %>%
    ggplot(aes(x = date, y = ect1)) +
        geom_line(col = "blue") +
        geom_hline(yintercept = -1, linetype = "dashed") +
        labs(x = "", y = "", col = "",
             title = "Cointegrating Relationship: Coefficient for 3-month Treasury Bill",
             subtitle = paste(window.length, "quarters rolling window"))

# plot p-value for the test of a restricted VEC with beta2=-1
results %>%
    dplyr::select(date, CA.rest) %>%
    mutate(CA.rest.pval = map_dbl(CA.rest, ~.@pval[1])) %>%
    ggplot(aes(x = date, y = CA.rest.pval)) +
        geom_hline(yintercept = 0.10, col = "gray70") +
        geom_hline(yintercept = 0.05, col = "gray40") +
        geom_hline(yintercept = 0.01, col = "gray10") +
        geom_line(col = "blue") +
        labs(x = "", y = "", col = "",
             title = "Restricted VEC test: p-value",
             subtitle = paste(window.length, "quarters rolling window"))

# plot estimated coefficients with confidence intervals
results %>%
    # mutate(VEC.coefs = map(VEC, ~(.$rlm %>% tidy()))) %>%
    mutate(VEC.coefs = map(VEC.rest, ~(.$rlm %>% tidy()))) %>%
    dplyr::select(date, VEC.coefs) %>%
    unnest() %>%
    ggplot(aes(x = date, y = estimate, group = term)) +
        geom_line(color = "royalblue") +
        geom_ribbon(aes(x = date, ymin = estimate - 1.96*std.error, ymax = estimate + 1.96*std.error), alpha = 0.5, fill = "lightblue") +
        geom_hline(yintercept = 0, color = "black")+
        labs(x = "", y = "",
             title = "Coefficient Estimates for Restricted VEC",
             subtitle = paste(window.length, "month rolling window VEC model"))+
        facet_grid(term  ~ response, scales = "free_y")

# 1 period ahead rolling forecasts
tbl.f.1.rol <-
    bind_rows(
        # actual data
        r.tbl %>%
            mutate(date = as.Date(qtryear)) %>%
            dplyr::select(date, r5, Tbill) %>%
            gather(variable, value, -date) %>%
            mutate(key = "actual"),
        # forecasts
        results %>%
            dplyr::select(date, VAR.f) %>%
            unnest(VAR.f) %>%
            rename(value = fcst) %>%
            mutate(key = "forecast",
                   date = date %m+% months(3))
    ) %>%
    arrange(date, variable)

# plot the 1 period ahead rolling forecasts
tbl.f.1.rol %>%
    ggplot(aes(x = date, y = value, col = key, group = key)) +
        geom_ribbon(aes(ymin = lower, ymax = upper), color = NA, fill = "steelblue", alpha = 0.2) +
        geom_line(size = 0.7) +
        scale_color_manual(values = c("black","blue")) +
        labs(x = "", y = "", title = "Rolling one step ahead forecast") +
        facet_grid(variable ~ ., scales = "free_y") +
        theme(legend.position = "none")
