cajorlsX <- function (z)
{
    if (!(class(z) == "ca.jo") && !(class(z) == "cajo.test")) {
        stop("\nPlease, provide object of class 'ca.jo' or 'cajo.test' as 'z'.\n")
    }
    P <- ncol(z@Z0)
    beta <- as.matrix(z@V[,1])
    ECT <- z@ZK %*% beta
    colnames(ECT) <- "ect1"
    colnames(beta) <- "ect1"
    rownames(beta) <- colnames(z@ZK)
    alpha <- as.matrix(z@W[,1])
    rownames(alpha) <- colnames(z@Z0)
    vecresult <- NULL
    if (.hasSlot(z,"A") && !is.null(z@A)) {
        ect <- ECT %*% t(z@A)
    }
    else {
        ect <- ECT %*% rep(1,P)
    }
    for (i in 1:P) {
        vecresult[[colnames(z@Z0)[i]]] <- lm(z@Z0[,i] ~ -1 + ., data = data.frame(ect[,i], z@Z1))
    }
    return(list(vecresult = vecresult, beta = beta, alpha = alpha))
}
