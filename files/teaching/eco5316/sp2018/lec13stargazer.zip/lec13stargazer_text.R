
library(Quandl)
rGDP <- Quandl("FRED/GDPC1", type="xts")
dlrGDP <- diff(log(rGDP))

ma2 <- arima(dlrGDP, order=c(0,0,2))
ar1 <- arima(dlrGDP, order=c(1,0,0))
ar3 <- arima(dlrGDP, order=c(3,0,0))
arma22 <- arima(dlrGDP, order=c(2,0,2))

library(stargazer)
stargazer(ar1, ar3, ma2, arma22, type="text")

