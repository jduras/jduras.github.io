
# linear Gaussian state space model - local level model with seasonality and exogenous variables

# clear environment
rm(list=ls())

# UK car accidents data
data("Seatbelts")
help("Seatbelts")

# drivers killed or critically injured
plot( log(Seatbelts[,"drivers"]) )

library(KFAS)

# define state-space model - local level with seasonality and two variables
y.SSM <- SSModel(log(drivers) ~ SSMtrend(degree = 1, Q = list(NA))
                                  + SSMseasonal(period = 12, sea.type = "dummy", Q = NA)
                                  + log(PetrolPrice)
                                  + law,
                 data = Seatbelts, H = NA)
y.SSM

# examine state
y.SSM$a
# examine system matrices
y.SSM$T
y.SSM$R
y.SSM$Q
y.SSM$Z
y.SSM$H

# define update function for maximum likelihhod estimation
updatefn_KSI <- function(pars,model,...){
    model$H[] <- exp(pars[1])
    diag(model$Q[,,1])<- exp(c(pars[2:3]))
    model
}

# estimate model parameters using maximum likelihhod
y.ML <- fitSSM(inits = log( rep(var(log(Seatbelts[,'drivers']))/10, 3) ),
              model = y.SSM,
              updatefn = updatefn_KSI,
              method = "Nelder-Mead")
str(y.ML$model)

# estimated parameters - variance of innovations in measurement equation, state level equation, seasonal component equation
res <- data.frame(sigma2.measurement = y.ML$model$H[,,1],
                  sigma2.level = diag(y.ML$model$Q[,,1])[1],
                  sigma2.seasonality = diag(y.ML$model$Q[,,1])[2])
res

y.ML$model$Q
y.ML$model$H

# Kalman filtering and smoothing
y.KFS <- KFS(y.ML$model, filtering = c("state"), smoothing = c("state","disturbance","mean"))
y.KFS

# smoothed state
str(y.KFS$alphahat)
dimnames(y.KFS$alphahat)

# number of observations
T <- dim(Seatbelts)[1]

# estimated parameters for two explanatory variables
y.KFS$alphahat[T,1]
y.KFS$alphahat[T,2]


# actual values
y <- log(Seatbelts[,"drivers"])

# extract smoothed level, seasonal, and irregular components
y.lvl.KS <- y.KFS$alphahat[,1]*log(as.data.frame(Seatbelts)$PetrolPrice) + y.KFS$alphahat[,2]*(as.data.frame(Seatbelts)$law) + y.KFS$alphahat[,"level"]
y.sea.KS  <- y.KFS$alphahat[,"sea_dummy1"]
y.eps.KS  <- y.KFS$epshat

# smoothed data combinining level, seasonal, and effects of exogenous variables
y.KS_all <- rep(NA, T)
for (t in 1:T) { y.KS_all[t] <- y.KFS$alphahat[t,] %*% y.KFS$model$Z[,,t] }
# can be also obtained using predict function with missing n.ahead option
y.KS_all.CI <- predict(y.KFS$model, interval = "confidence", level = 0.9)

# check to see that the above two methods yield same results
cbind(y.KS_all, y.KS_all.CI)

par(mfrow = c(3,1), cex = 0.7)

# actual data and smoothed state component
cbind(y, y.lvl.KS) %>% ts(start = 1969, frequency = 12 ) %>%
    plot.ts(plot.type = "single", xlab = "", ylab = "log KSI", col = c("darkgrey","red"), lwd = c(1,2))
abline(v = 1969:2003, lty = "dotted", col = "lightgrey")
legend("topright", c("actual data","Kalman smoothed level"), col = c("darkgrey","red"), lwd = c(1,2), bty = "n")

# smoothed seasonal component
y.sea.KS %>% ts(start = 1969, frequency = 12) %>%
    plot(xlab = "", ylab = "log KSI", col = "red", lwd = 2)
abline(h = 0, col = "grey")
abline(v = 1969:2003, lty = "dotted", col = "lightgrey")
legend("topright", "Kalman smoothed seasonal component", col = "red", lwd = 2, bty = "n")

# smoothed irregular component
y.eps.KS %>% ts(start = 1969, frequency = 12) %>%
    plot(xlab = "", ylab = "log KSI", col = "red", lwd = 2)
abline(h = 0, col = "grey")
abline(v = 1969:2003, lty = "dotted", col = "lightgrey")
legend("topright", "irregular component", col = "red", lwd = 2, bty = "n")

