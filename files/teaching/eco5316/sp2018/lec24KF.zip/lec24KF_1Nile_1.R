
library(magrittr)
library(dplyr)
library(tidyr)
library(purrr)
library(timetk)
library(KFAS)
library(ggplot2)
library(ggfortify)

theme_set(theme_bw())

# linear Gaussian state space model - local level model for annual flow of river Nile at Ashwan, from 1871 to 1970

# clear the environment
rm(list=ls())

# annual flow of the Nile from 1871-1970
data(Nile)
help(Nile)
plot(Nile)

y.ts <- datasets::Nile

# uncomment the following two line to see the analysis with missing values
# y.ts[21:50] <- NA
# y.ts[71:80] <- NA

plot(y.ts)

# define the state-space local level model
y.LLM <- SSModel(y.ts ~ SSMtrend(degree = 1, Q = list(NA)), H = NA)
str(y.LLM)

# check state variable
y.LLM$a
# check system matrices
y.LLM$Z
y.LLM$T
y.LLM$R
y.LLM$H
y.LLM$Q


# initials values for paramaters of Q and H used by numerical procedure below to maximize loglikelihood
initvals <- list()
initvals[[1]] <- rep(1, 2)
initvals[[2]] <- rep(0.9, 2)
initvals[[3]] <- rep(1.1, 2)
initvals[[4]] <- rep(var(y.ts, na.rm = TRUE), 2)
initvals[[5]] <- rep(var(y.ts, na.rm = TRUE), 2)/1000


# update function which updates model matrices H and Q given new parameters
updatefun <- function(pars, model, ...){
    model$Q[] <- exp(pars[1])
    model$H[] <- exp(pars[2])
    model
}


# method for finding the maximum loglikelihood (or more precisely minimum of -loglikelihood)
#  Nelder-Mead uses only function values and is relatively slow but robust
#  BFGS is a quasi-Newton method, uses function values and gradients, it is faster than Nelder-Mead but does not always converge to a global mimimum
#  CG is a conjugate gradients method which is generally more fragile than BFGS but can be more successful in much larger optimization problems
methods <- list()
methods[[1]] <- "BFGS"
methods[[2]] <- "Nelder-Mead"
methods[[3]] <- "CG"


# maximum likelihood estimation of paramaters of Q and H (i.e. variance of the two inovations)
y.LLM.ML <- fitSSM(y.LLM, inits = log(rep(1.1, 2)), method = "BFGS")
y.LLM.ML$optim.out
exp(y.LLM.ML$optim.out$par)
y.LLM.ML$model$Q
y.LLM.ML$model$H

y.LLM.ML <- fitSSM(y.LLM, inits = log(rep(1.1, 2)), updatefn = updatefun, method = "BFGS")
y.LLM.ML$optim.out
exp(y.LLM.ML$optim.out$par)
y.LLM.ML$model$Q
y.LLM.ML$model$H

y.LLM.ML <- fitSSM(y.LLM, inits = log(rep(var(y.ts, na.rm = TRUE), 2)/100), method = "BFGS")
y.LLM.ML$optim.out
exp(y.LLM.ML$optim.out$par)
y.LLM.ML$model$Q
y.LLM.ML$model$H

# try different starting points and methods
y.LLM.ML.out.tbl <- list()
r <- 1
for (m in seq_along(methods)) {
    y.LLM.ML.out.tbl[[m]] <- list()
    for (i in seq_along(initvals)) {
        y.LLM.ML.tmp <- fitSSM(y.LLM, inits = initvals[[i]], method = methods[[m]])
        # y.LLM.ML.tmp <- fitSSM(y.LLM, inits = log(initvals[[i]]), method = methods[[m]], control = list(maxit = 5000))
        y.LLM.ML.out.tbl[[r]] <- tibble(method = methods[[m]], inits = initvals[i], out = list(y.LLM.ML.tmp$optim.out))
        r <- r + 1
    }
}
y.LLM.ML.out.tbl <- bind_rows(y.LLM.ML.out.tbl)

# report results: column LL contains the value of likelihood function that's being maximized
y.LLM.ML.out.tbl %>%
    mutate(LL = -map_dbl(out, ~.$value),
           inits1 = map_dbl(inits, ~.[1]),
           inits2 = map_dbl(inits, ~.[2]),
           par1 = map_dbl(out, ~.$par[1]),
           par2 = map_dbl(out, ~.$par[2]),
           par1.exp = map_dbl(out, ~exp(.$par[1])),
           par2.exp = map_dbl(out, ~exp(.$par[2]))) %>%
    arrange(desc(LL)) %>%
    select(method, LL, inits1, inits2, par1, par2, par1.exp, par2.exp)



# run Kalman Filter and Smoother with estimated parameters
y.KFS <- KFS(y.LLM.ML$model)
str(y.KFS)
names(y.KFS)

?predict.SSModel

# construct 90% confidence intervals for filtered state - shorter way, using predict function with missing n.ahead option
y.KF <- predict(y.LLM.ML$model, interval = "confidence", level = 0.9, filtered = TRUE)
# construct 90% confidence intervals for smoothed state
y.KS <- predict(y.LLM.ML$model, interval = "confidence", level = 0.9)

str(y.KS)

# construct 90% confidence intervals for filtered state - longer, do it yourself way
y.KF_2 <- as.vector(y.KFS$a) + sqrt(cbind(y.KFS$P)) %*% as.vector( qnorm(0.95)*c(-1,1) )
# construct 90% confidence intervals for smoothed state
y.KS_2 <- as.vector(y.KFS$alphahat) + sqrt(cbind(y.KFS$V)) %*% as.vector( qnorm(0.95)*c(-1,1) )

# replace the filtered state for first period by NA
y.KF[1,] <- NA

# compare confidence intervals
cbind(y.KF, y.KF_2[-(T+1),]) %>% head()
cbind(y.KS, y.KS_2) %>% head()



par(mfrow = c(2,2), cex = 0.6)
# plot filtered state
plot.ts( cbind(y.ts, y.KF, Nile), plot.type = "single",
         col = c(1,4,4,4,1), lwd = c(2,2,2,2,1), lty = c(1,1,2,2,3), xlab = "", ylab = "", main = "")
abline(v = 1898, lty = 3)
legend("topright", legend = c("data","filtered state","90% confidence interval"),
       col = c("black","blue","blue"), lty = c(1,1,2), lwd = c(1,1,1), bty = "n", cex = 0.9 )
plot( ts( c(y.KFS$v[-1]), start = 1871), col = "blue", lwd = 2, xlab = "", ylab = "", main = "forecast error")
abline(h = 0, lty = 3)
plot( ts( c(y.KFS$P)[-1], start = 1871), col = "blue", lwd = 2, xlab = "", ylab = "", main = "variance of state")
plot( ts( c(y.KFS$F)[-1], start = 1871), col = "blue", lwd = 2, xlab = "", ylab = "", main = "variance of forecast error")


par(mfrow = c(1,2), mar = c(3,3,2,1), cex = 0.8)
# filtered
cbind(y.ts, y.KF, Nile) %>%
    plot.ts(plot.type = "single", col = c(1,4,4,4,1), lwd = c(2,2,2,2,1), lty = c(1,1,2,2,3), xlab = "", ylab = "", main="")
abline(v = 1898, lty = 3)
legend("topright", legend=c("data","filtered","90% confidence interval"), col = c(1,4,4), lty = c(1,1,2), lwd = 2, bty = "n", cex = 0.9 )
# smoothed
cbind(y.ts, y.KS, Nile) %>%
    plot.ts(plot.type = "single", col = c(1,2,2,2,1), lwd = c(2,2,2,2,1), lty = c(1,1,2,2,3), xlab = "", ylab = "", main = "")
abline(v = 1898, lty = 3)
legend("topright", legend = c("data","smoothed","90% confidence interval"), col = c(1,2,2), lty = c(1,1,2), lwd = 2, bty = "n", cex = 0.9 )





# plot smoothed state using ggplot with ggfortify
autoplot(y.KFS) +
    labs(x = "", y = "",
         title = "Annual flow of river Nile at Ashwan",
         subtitle = "Actual series vs Kalman smoothed series with 90% confidence interval")

# plot smoothed state with confidence interval using ggplot
cbind(y.ts, y.KS) %>%
    tk_tbl(rename_index = "year") %>%
    gather(variable, value, -year) %>%
    mutate(linetypes = case_when(variable == "y.ts" ~ "solid",
                                 variable == "y.KS.fit" ~ "solid",
                                 variable == "y.KS.lwr" ~ "dashed",
                                 variable == "y.KS.upr" ~ "dashed")) %>%
    ggplot(aes(x = year, y = value, group = variable, col = variable, linetype = linetypes)) +
        geom_line() +
        geom_vline(xintercept = 1898, linetype = "dashed") +
        annotate("text", x = 1896, y = 600, angle = 90, label = "Ashwan dam built") +
        scale_color_manual(values = c("red","red","red","black")) +
        scale_linetype_identity() +
        labs(x = "", y = "",
             title = "Annual flow of river Nile at Ashwan",
             subtitle = "Actual series vs Kalman smoothed series with 90% confidence interval") +
        theme(legend.position = "none")

# plot filtered and smoothed state with confidence interval using ggplot
g <- cbind(y.KS.actual = y.ts, y.KS, y.KF.actual = y.ts, y.KF) %>%
    tk_tbl(rename_index = "year") %>%
    gather(variable, value, -year) %>%
    separate(variable, into = c("y","method","key")) %>%
    mutate(linetypes = if_else(key %in% c("lwr","upr"), "dashed", "solid"),
           colors = case_when(key == "actual" ~ "black",
                              method == "KS" ~ "red",
                              method == "KF" ~ "blue"),
           method.label = case_when(method == "KS" ~ "smoothed",
                                    method == "KF" ~ "filtered")) %>%
    ggplot(aes(x = year, y = value, group = key, col = colors, linetype = linetypes)) +
        geom_line() +
        geom_vline(xintercept = 1898, linetype = "dashed") +
        annotate("text", x = 1896, y = 600, angle = 90, label = "Ashwan dam built") +
        scale_color_identity() +
        scale_linetype_identity() +
        labs(x = "", y = "",
             title = "Annual flow of river Nile at Ashwan",
             subtitle = "Actual series vs Kalman filtered and smoothed series with 90% confidence interval") +
        facet_wrap(~method.label)
g

library(plotly)
ggplotly(g)

# plot filtered and smoothed state with confidence interval using ggplot
g <- cbind(y.KS.actual = y.ts, y.KS, y.KF.actual = y.ts, y.KF) %>%
    tk_tbl(rename_index = "year") %>%
    gather(variable, value, -year) %>%
    separate(variable, into = c("y","method","key")) %>%
    mutate(component = case_when(key == "actual"                          ~ "data",
                                 method == "KS" & key == "fit"            ~ "smoothed",
                                 method == "KF" & key == "fit"            ~ "filtered",
                                 method == "KS" & key %in% c("lwr","upr") ~ "smoothed, 90 % confidence interval",
                                 method == "KF" & key %in% c("lwr","upr") ~ "filtered, 90 % confidence interval"),
           method.label = case_when(method == "KS" ~ "smoothed",
                                    method == "KF" ~ "filtered")) %>%
    ggplot(aes(x = year, y = value, group = key, col = component, linetype = component)) +
        geom_line() +
        geom_vline(xintercept = 1898, linetype = "dashed") +
        annotate("text", x = 1900, y = 430, hjust = 0, angle = 0, label = "Ashwan dam built") +
        scale_color_manual(values = c("black","blue","blue","red","red")) +
        scale_linetype_manual(values = c("solid","solid","dotted","solid","dotted")) +
        labs(x = "", y = "",
             title = "Annual flow of river Nile at Ashwan",
             subtitle = "Actual series vs Kalman filtered and smoothed series with 90% confidence interval",
             col = "", linetype = "") +
        facet_wrap(~method.label)
g

library(plotly)
ggplotly(g)
