
library(readr)
library(magrittr)
library(dplyr)
library(purrr)
library(timetk)
library(KFAS)


# linear Gaussian state space model - capital asset price model with time varying coefficients

# clear environment
rm(list=ls())

# load data on excess returns from January 1990 to December 2003
er.tbl <- read_delim("http://faculty.chicagobooth.edu/ruey.tsay/teaching/fts3/m-excess-c10sp-9003.txt", delim = " ")

# excess returns for General Motors and for S&P 500
er.ts <-
    er.tbl %>%
    select(SP5, GM) %>%
    rename(SP500 = SP5) %>%
    ts(start = 1990, frequency = 12)

er.ts %>% plot()

# estimate a simple capital asset pricing model (CAPM) regression
#  r = alpha + betta*rM + eps
GM.CAPM.OLS <- lm(GM ~ SP500, data = as.data.frame(er.ts))
summary(GM.CAPM.OLS)

er.ts %>% as.data.frame() %>% plot()
abline(GM.CAPM.OLS)



# get number of observatons
T <- nrow(er.ts)

# construct system matrices for state-space model - CAPM with time variable alpha and betta
Zt <- rbind(rep(1,T), er.ts[,"SP500"]) %>% array(dim = c(1,2,T))
Ht <- matrix(NA)
Tt <- diag(2)
Rt <- diag(2)
Qt <- matrix(c(NA,0,0,NA), 2,2)

# use diffuse prior
a1 <- matrix(c(0,1), 2, 1)
P1 <- matrix(0,2,2)
P1inf <- diag(2)


# define state-space CAPM model
er.SSM <- SSModel(GM ~ -1 + SSMcustom(Z = Zt, T = Tt, R = Rt, Q = Qt, a1 = a1, P1 = P1, P1inf = P1inf), H = Ht, data = er.ts)
er.SSM

# check system matrices
er.SSM$T
er.SSM$R
er.SSM$Z
er.SSM$Q
er.SSM$H

er.SSM$P1
er.SSM$P1inf

# # note: the aboce state space model can be also constructed using SSMregression as follows
# er.SSM <- SSModel(GM ~ -1 + SSMregression(~ rep(1,T) + SP500, Q = diag(NA,2)), H = NA, data = er.ts)
# # here -1 and rep(1,T) is used so that the intercept is also subject to innovations in state transition equation,
# # as can be seen from matrices T, R, Q
# er.SSM$T
# er.SSM$R
# er.SSM$Q
# # in other words, using
# er.SSM <- SSModel(GM ~ SSMregression(~ SP500, Q = NA), H = NA, data = er.ts)
# # implies that intercept is constant, not subject to innovations in state transition equation as can be seen from matrices T, R, Q
# er.SSM$T
# er.SSM$R
# er.SSM$Q

# initials values for paramaters of Q and H used by numerical procedure below to maximize loglikelihood
initvals <- list()
initvals[[1]] <- rep(1, 3)
initvals[[2]] <- rep(0.9, 3)
initvals[[3]] <- rep(1.1, 3)
initvals[[4]] <- rep(var(er.ts[,"GM"], na.rm = TRUE), 3)
initvals[[5]] <- rep(var(er.ts[,"GM"], na.rm = TRUE), 3)/100

# method for finding the maximum loglikelihood (or more precisely minimum of -loglikelihood)
#  Nelder-Mead uses only function values and is relatively slow but robust
#  BFGS is a quasi-Newton method, uses function values and gradients, it is faster than Nelder-Mead but does not always converge to a global mimimum
#  CG is a conjugate gradients method which is generally more fragile than BFGS but can be more successful in much larger optimization problems
methods <- list()
methods[[1]] <- "BFGS"
methods[[2]] <- "Nelder-Mead"
methods[[3]] <- "CG"

er.SSM.ML.out.tbl <- list()
r <- 1
for (m in seq_along(methods)) {
    er.SSM.ML.out.tbl[[m]] <- list()
    for (i in seq_along(initvals)) {
        er.SSM.ML.tmp <- fitSSM(er.SSM, inits = log(initvals[[i]]), method = methods[[m]], control = list(maxit = 1000))
        er.SSM.ML.out.tbl[[r]] <- tibble(method = methods[[m]], inits = initvals[i], out = list(er.SSM.ML.tmp$optim.out))
        r <- r + 1
    }
}
er.SSM.ML.out.tbl <- bind_rows(er.SSM.ML.out.tbl)

er.SSM.ML.out.tbl %>%
    mutate(LL = -map_dbl(out, ~.$value),
           inits1 = map_dbl(inits, ~.[1]),
           inits2 = map_dbl(inits, ~.[2]),
           inits3 = map_dbl(inits, ~.[3]),
           par1.exp = map_dbl(out, ~exp(.$par[1])),
           par2.exp = map_dbl(out, ~exp(.$par[2])),
           par3.exp = map_dbl(out, ~exp(.$par[3]))) %>%
    arrange(desc(LL)) %>%
    select(method, LL, inits1, inits2, inits3, par1.exp, par2.exp, par3.exp)

# estimate variances of innovations using maximum likelihood
er.SSM.ML <- fitSSM(er.SSM, inits = log(initvals[[1]]), method = "Nelder-Mead", control = list(maxit = 5000))
er.SSM.ML$optim.out
exp(er.SSM.ML$optim.out$par)
er.SSM.ML$model$Q
er.SSM.ML$model$H


# Kalman filtering and smoothing, with parameters in Q and H set to maximum likelihood estimates
er.SSM.KFS <- KFS(er.SSM.ML$model)
er.SSM.KFS
str(er.SSM.KFS)
names(er.SSM.KFS)

head(er.SSM.KFS$a)
head(er.SSM.KFS$alphahat)

# extract filtered and smoothed alpha and betta
alpha.KFS <- cbind(er.SSM.KFS$a[,1], er.SSM.KFS$alphahat[,1]) %>% ts(start=c(1990,1), frequency=12)
betta.KFS <- cbind(er.SSM.KFS$a[,2], er.SSM.KFS$alphahat[,2]) %>% ts(start=c(1990,1), frequency=12)

par(mfcol=c(2,2))

# plot filtered and smoothed state alpha and betta
plot.ts(alpha.KFS, plot.type="single", xlab="",ylab="alpha", col=c("blue","red"), lwd=2)
legend("topright", c("filtered","smoothed"), col=c("blue","red"), lwd=2, cex=0.7, bty="n")
plot.ts(betta.KFS, plot.type="single", xlab="",ylab="betta", col=c("blue","red"), lwd=2)
legend("topright", c("filtered","smoothed"), col=c("blue","red"), lwd=2, cex=0.7, bty="n")

# plot smoothed state alpha and betta
plot.ts(alpha.KFS[,2], plot.type="single", xlab="",ylab="alpha", col="red", lwd=2)
legend("topright", "smoothed", col="red", lwd=2, cex=0.7, bty="n")
plot.ts(betta.KFS[,2], plot.type="single", xlab="",ylab="betta", col="red", lwd=2)
legend("topright", "smoothed", col="red", lwd=2, cex=0.7, bty="n")

